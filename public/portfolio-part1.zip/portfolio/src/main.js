import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';

import {
  TOTAL_STORY_VH,
  TIMELINE,
  OS_TIMES,
  clamp,
  lerp,
  range,
  ease,
  easeOutBack,
  computeTimelineState,
  getFirstUnfinishedGate,
  limitScrollPv,
} from './timeline.js';
import { cardUniforms, disposeCardboard } from './cardboard.js';
import {
  ensureDisplayFont,
  createFirstStoryScreenTexture,
  createCrtMaterial,
  createModernScreenTexture,
} from './crt-screen.js';
import { createConnectScreen } from './connect-screen.js';
import { buildOrLoadRoom } from './room.js';
import { createWallTextManager } from './html-text.js';
import { createOsLayer } from './os.js';
import { startMusic, playMusic, muteMusic, sfx, riser } from './music.js';
import { runCanvas2DFallback } from './canvas2d-fallback.js';

/**
 * Cross-module exports for Part 2 integration:
 * - warm(fn): idle-time queue for heavy blocks
 * - setBarColor(css): sets mobile browser theme-color and root background
 * - music / sfx / riser controls
 */
const warmQueue = [];
let warmRunning = false;

export function warm(fn) {
  if (typeof fn !== 'function') return;
  warmQueue.push(fn);
  if (!warmRunning) {
    warmRunning = true;
    const schedule = window.requestIdleCallback || ((cb) => window.setTimeout(cb, 32));
    const step = () => {
      const task = warmQueue.shift();
      if (task) {
        try {
          task();
        } catch (e) {}
      }
      if (warmQueue.length > 0) {
        schedule(step);
      } else {
        warmRunning = false;
      }
    };
    schedule(step);
  }
}

let customBarColor = null;
export function setBarColor(cssColor) {
  customBarColor = cssColor || null;
  if (cssColor) {
    const meta = document.getElementById('theme-color-meta');
    if (meta) meta.setAttribute('content', cssColor);
    document.documentElement.style.backgroundColor = cssColor;
  }
}

export { startMusic, playMusic, muteMusic, sfx, riser };

window.PortfolioAPI = {
  warm,
  setBarColor,
  startMusic,
  playMusic,
  muteMusic,
  sfx,
  riser,
};

// ============================================================================
// CUSTOM FILM SHADER PASS (Chromatic Aberration, 9-Tap Edge Blur, Warm/Cool
// Grade, S-Curve Contrast, Lifted Blacks, Film Grain, Vignette)
// ============================================================================
const FilmShader = {
  uniforms: {
    tDiffuse: { value: null },
    uResolution: { value: new THREE.Vector2(1440, 900) },
    uBlur: { value: 0.0008 },
    uWarm: { value: 1.0 },
    uTime: { value: 0.0 },
    uGrainAmp: { value: 0.028 },
  },
  vertexShader: `
    varying highp vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform highp vec2 uResolution;
    uniform highp float uBlur;
    uniform highp float uWarm;
    uniform highp float uTime;
    uniform highp float uGrainAmp;
    varying highp vec2 vUv;

    float hash12(vec2 p) {
      vec3 p3 = fract(vec3(p.xyx) * 0.1031);
      p3 += dot(p3, p3.yzx + 33.33);
      return fract((p3.x + p3.y) * p3.z);
    }

    void main() {
      vec2 c = vUv - 0.5;
      float aspect = uResolution.x / max(1.0, uResolution.y);
      vec2 propC = vec2(c.x * min(1.0, aspect), c.y * min(1.0, 1.0 / aspect));
      float edgeDist = length(propC);
      float edgeFactor = smoothstep(0.14, 0.68, edgeDist);

      // Cheap 9-tap lens blur sharp in centre, soft at edges + chromatic aberration
      float rBlur = uBlur * edgeFactor;
      vec2 caOffset = c * (0.0022 * edgeFactor);

      vec3 sum = vec3(0.0);
      float totalW = 0.0;
      for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
          vec2 off = vec2(float(x), float(y)) * rBlur;
          float w = (x == 0 && y == 0) ? 4.0 : (x == 0 || y == 0) ? 2.0 : 1.0;
          float r = texture2D(tDiffuse, clamp(vUv + off - caOffset, 0.001, 0.999)).r;
          float g = texture2D(tDiffuse, clamp(vUv + off, 0.001, 0.999)).g;
          float b = texture2D(tDiffuse, clamp(vUv + off + caOffset, 0.001, 0.999)).b;
          sum += vec3(r, g, b) * w;
          totalW += w;
        }
      }
      vec3 col = sum / totalW;

      // Warm-tungsten to cool-modern grade driven by uWarm
      vec3 warmTint = vec3(1.06, 0.99, 0.91);
      vec3 coolTint = vec3(0.95, 0.99, 1.06);
      col *= mix(coolTint, warmTint, uWarm);

      // Subtle S-curve contrast + lifted blacks
      vec3 sc = col * col * (3.0 - 2.0 * col);
      col = mix(col, sc, 0.24);
      col = mix(vec3(0.025, 0.032, 0.065), col, 0.975);

      // Film grain
      float grain = (hash12(vUv * uResolution + vec2(uTime * 37.0, uTime * 19.0)) - 0.5) * uGrainAmp;
      col += grain;

      // Vignette
      float vig = mix(0.62, 1.0, smoothstep(0.82, 0.22, length(c * vec2(1.0, 1.12))));
      col *= vig;

      gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
    }
  `,
};

// ============================================================================
// MAIN APPLICATION INIT
// ============================================================================
async function initPortfolioStory() {
  if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
  }

  const params = new URLSearchParams(window.location.search);
  const paramP = params.has('p') ? parseFloat(params.get('p')) : null;
  const paramV = params.has('v') ? parseFloat(params.get('v')) : null;
  const paramMod = params.has('mod') ? parseFloat(params.get('mod')) : null;
  const paramQ = params.has('q') ? parseInt(params.get('q'), 10) : null;
  const paramDpr = params.has('dpr') ? parseFloat(params.get('dpr')) : null;
  const paramSkin = params.has('skin') ? parseInt(params.get('skin'), 10) : null;
  const paramNoStory = params.has('nostory');
  const paramReduceMotion = params.get('motion') === 'reduce';

  const paramDebug = params.has('debug');

  const mediaReduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  const isReducedMotion = () => paramReduceMotion || mediaReduce.matches;
  if (isReducedMotion()) {
    document.documentElement.classList.add('reduce-motion');
  }

  const canvas = document.getElementById('scene');
  const loaderEl = document.getElementById('loader');
  const loaderGlow = document.getElementById('loader-glow');
  const loaderStatus = document.getElementById('loader-status');
  const loaderFile = document.getElementById('loader-file');
  const loaderPct = document.getElementById('loader-pct');
  const headerEl = document.getElementById('top-header');
  const skipBtn = document.getElementById('skip-btn');
  const replayBtn = document.getElementById('replay-btn');
  const hintPill = document.getElementById('hint-pill');
  const hintText = document.getElementById('hint-text');
  const eraAnnouncer = document.getElementById('era-announcer');
  const contentEl = document.getElementById('content');
  const langToggle = document.getElementById('lang-toggle');
  const logoTopLink = document.getElementById('logo-top-link');

  if (langToggle) {
    langToggle.addEventListener('click', () => {
      if (window.toggleLang) window.toggleLang();
      sfx('click', 0.22);
    });
  }

  // Canvas dimensions helper (always reads the 100lvh canvas, not window)
  const VW = () => canvas.clientWidth || window.innerWidth;
  const VH = () => canvas.clientHeight || window.innerHeight;
  const isPhone = () => VW() < 768 || window.matchMedia('(pointer: coarse)').matches;

  // Loader state & pointer glow
  let realLoadPct = 5;
  let shownLoadPct = 0;
  const loaderGlowPos = { x: VW() * 0.5, y: VH() * 0.5, tx: VW() * 0.5, ty: VH() * 0.5 };

  window.addEventListener(
    'pointermove',
    (e) => {
      loaderGlowPos.tx = e.clientX;
      loaderGlowPos.ty = e.clientY;
    },
    { passive: true }
  );

  function showLoaderFailureMessage(customEn, customFil) {
    const errCopy = window.STORY_COPY?.loaderError;
    const msgEn = customEn || errCopy?.en || "Couldn't load 3D scene, please refresh";
    const msgFil = customFil || errCopy?.fil || 'Hindi ma-load ang 3D eksena, paki-refresh';
    if (loaderStatus) {
      loaderStatus.textContent = window.L ? window.L(msgEn, msgFil) : msgEn;
    }
    if (loaderFile) {
      loaderFile.textContent = 'gpu/shader_fallback_failed';
    }
    document.body.classList.remove('ready');
  }

  function updateLoaderText(pct) {
    const stages = window.STORY_COPY?.loader || [];
    let chosen = stages[0];
    for (const s of stages) {
      if (pct >= s.threshold) chosen = s;
    }
    if (pct >= 97 && pct < 100) {
      const wu = window.STORY_COPY?.loaderWarmup;
      loaderStatus.textContent = window.L ? window.L(wu?.en || 'Warming up', wu?.fil || 'Inihahanda') : 'Warming up';
      loaderFile.textContent = 'gpu/compile_shaders.bin';
    } else if (chosen) {
      loaderStatus.textContent = window.L ? window.L(chosen.en, chosen.fil) : chosen.en;
      loaderFile.textContent = chosen.file;
    }
    loaderPct.textContent = `${Math.round(pct)}%`;
  }

  // ==========================================================================
  // THREE.JS SCENE, RENDERER & CAPABILITIES INSPECTION
  // Pre-acquire the WebGL context BEFORE constructing THREE.WebGLRenderer so
  // Three.js never registers its console.error webglcontextcreationerror handler
  // on environments where WebGL is disabled (GL_VENDOR = Disabled) or when
  // falling back from high-performance/antialias attributes.
  // ==========================================================================
  function acquireWebGLContext(targetCanvas, wantAntialias) {
    const attempts = [
      {
        type: 'webgl2',
        attrs: {
          alpha: false,
          depth: true,
          stencil: false,
          antialias: wantAntialias,
          powerPreference: 'default',
        },
      },
      {
        type: 'webgl2',
        attrs: {
          alpha: false,
          depth: true,
          stencil: false,
          antialias: false,
        },
      },
      { type: 'webgl2', attrs: undefined },
      {
        type: 'webgl',
        attrs: {
          alpha: false,
          depth: true,
          stencil: false,
          antialias: false,
        },
      },
      { type: 'experimental-webgl', attrs: undefined },
    ];

    for (const attempt of attempts) {
      try {
        const ctx = attempt.attrs
          ? targetCanvas.getContext(attempt.type, attempt.attrs)
          : targetCanvas.getContext(attempt.type);
        if (ctx && typeof ctx.getParameter === 'function' && !ctx.isContextLost()) {
          return ctx;
        }
      } catch (e) {}
    }
    return null;
  }

  const wantAa = paramQ !== 0 && !isPhone();
  const acquiredGl = acquireWebGLContext(canvas, wantAa);

  let renderer = null;
  if (acquiredGl) {
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        context: acquiredGl,
        antialias: wantAa,
        alpha: false,
      });
    } catch (err) {
      renderer = null;
    }
  }

  if (!renderer) {
    await runCanvas2DFallback({
      canvas,
      params,
      paramP,
      paramV,
      paramMod,
      paramDebug,
      isReducedMotion,
      isPhone,
      VW,
      VH,
      updateLoaderText,
      headerEl,
      skipBtn,
      replayBtn,
      hintPill,
      hintText,
      eraAnnouncer,
      contentEl,
      logoTopLink,
      sfx,
      startMusic,
    });
    return;
  }

  // Inspect GPU & capabilities directly on renderer.getContext() (no throwaway context loss)
  const gl = renderer.getContext();
  const debugRendererExt = gl ? gl.getExtension('WEBGL_debug_renderer_info') : null;
  const unmaskedRenderer = String(
    (gl &&
      gl.getParameter(
        debugRendererExt ? debugRendererExt.UNMASKED_RENDERER_WEBGL : gl.RENDERER
      )) ||
      'unknown'
  );
  const maxTexImageUnits = gl ? gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS) : 16;

  const isSoftwareGl = /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(unmaskedRenderer);
  const isStrongGpu = /NVIDIA|Radeon RX|GeForce|RTX|GTX/i.test(unmaskedRenderer);
  const isWeakGpu =
    isSoftwareGl ||
    maxTexImageUnits <= 8 ||
    (!isStrongGpu && /Intel|UHD|Iris|Mali|Adreno|PowerVR|Apple GPU/i.test(unmaskedRenderer));

  // Requirement 1: Log renderer.capabilities, gl.MAX_TEXTURE_IMAGE_UNITS, and UNMASKED_RENDERER_WEBGL when ?debug is set
  if (paramDebug) {
    console.info('[WebGL Debug] UNMASKED_RENDERER_WEBGL:', unmaskedRenderer);
    console.info('[WebGL Debug] gl.MAX_TEXTURE_IMAGE_UNITS:', maxTexImageUnits);
    console.info('[WebGL Debug] renderer.capabilities:', {
      maxTextures: renderer.capabilities.maxTextures,
      maxVertexTextures: renderer.capabilities.maxVertexTextures,
      maxVaryings: renderer.capabilities.maxVaryings,
      maxVertexUniforms: renderer.capabilities.maxVertexUniforms,
      maxFragmentUniforms: renderer.capabilities.maxFragmentUniforms,
    });
  }

  // Requirement 2: Enable checkShaderErrors and print full vertex/fragment source + gl.getShaderInfoLog for first failing program
  let firstShaderErrorLogged = false;
  let shaderCompileFailed = false;
  renderer.debug.checkShaderErrors = true;
  renderer.debug.onShaderError = (glCtx, program, glVertexShader, glFragmentShader) => {
    shaderCompileFailed = true;
    if (!firstShaderErrorLogged) {
      firstShaderErrorLogged = true;
      const vsSource = glCtx.getShaderSource(glVertexShader);
      const fsSource = glCtx.getShaderSource(glFragmentShader);
      const vsLog = glCtx.getShaderInfoLog(glVertexShader);
      const fsLog = glCtx.getShaderInfoLog(glFragmentShader);
      const progLog = glCtx.getProgramInfoLog(program);
      console.error('[WebGL Shader Error] First failing program diagnostic:', {
        programInfoLog: progLog,
        vertexShaderInfoLog: vsLog,
        fragmentShaderInfoLog: fsLog,
        vertexShaderSource: vsSource,
        fragmentShaderSource: fsSource,
      });
    }
  };

  // Quality tiers: 2 = AO + bloom, 1 = bloom only, 0 = minimal
  let qualityTier =
    paramQ !== null && !Number.isNaN(paramQ)
      ? clamp(paramQ, 0, 2)
      : isSoftwareGl
      ? 0
      : isPhone() || isWeakGpu
      ? 1
      : 2;

  function computeInitialDpr() {
    if (paramDpr !== null && !Number.isNaN(paramDpr)) {
      return clamp(paramDpr, 0.5, 2.5);
    }
    if (isSoftwareGl) return 1.0;
    const rawDpr = window.devicePixelRatio || 1;
    if (isPhone()) {
      const budget = Math.sqrt(650000 / Math.max(1, VW() * VH()));
      return Math.max(1.0, Math.min(rawDpr, 2.0, budget));
    }
    return isWeakGpu ? Math.min(rawDpr, 0.75) : Math.min(rawDpr, 1.5);
  }

  let currentDpr = computeInitialDpr();
  let pendingDpr = null;

  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.AgXToneMapping || THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.setPixelRatio(currentDpr);
  renderer.setSize(VW(), VH(), false);
  renderer.shadowMap.enabled = !isSoftwareGl && qualityTier > 0;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = false;

  const scene = new THREE.Scene();
  const nightBgColor = new THREE.Color(0x0b1020);
  const hazeBgColor = new THREE.Color(0x5a4436);
  const currentFogColor = new THREE.Color(0x5a4436);
  scene.background = currentFogColor;
  scene.fog = new THREE.FogExp2(0x5a4436, 0.08);

  const camera = new THREE.PerspectiveCamera(45, VW() / VH(), 0.08, 25);

  function buildEnvironmentMap() {
    if (qualityTier === 0) {
      scene.environment = null;
      return;
    }
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    if ('environmentIntensity' in scene) {
      scene.environmentIntensity = 0.05;
    }
    pmrem.dispose();
  }
  buildEnvironmentMap();

  realLoadPct = 28;
  await ensureDisplayFont();
  realLoadPct = 45;

  // Build CRT & Modern Screen textures
  const maxAniso = renderer.capabilities.getMaxAnisotropy();
  const firstScreen = createFirstStoryScreenTexture(maxAniso);
  const modernScreenTex = createModernScreenTexture(isPhone());
  const crtMaterial = createCrtMaterial(firstScreen.texture);

  // Build or Load the 3D Room (single shadow-casting light, single envMap, atlased textures)
  let room;
  try {
    room = await buildOrLoadRoom({
      scene,
      crtMaterial,
      modernScreenTexture: modernScreenTex,
      isPhone: isPhone(),
      isWeakGpu,
      maxTextures: renderer.capabilities.maxTextures || maxTexImageUnits,
      useAlphaFade: isPhone() || isReducedMotion(),
      onProgress: (p) => {
        realLoadPct = 45 + Math.round(p * 42);
      },
    });
  } catch (err) {
    showLoaderFailureMessage();
    return;
  }

  if (paramDebug && room.samplerStats) {
    console.info('[WebGL Debug] Material texture sampler counts:', room.samplerStats);
  }

  // Create Connect Screen and bind to CRT material until connected
  let entered = false;
  let tubeFlickerStart = -1;

  const connectScreen = createConnectScreen({
    screenMesh: room.oldScreen,
    camera,
    domElement: canvas,
    sfx,
    maxAnisotropy: maxAniso,
    onConnected: () => {
      startMusic();
      tubeFlickerStart = performance.now();
    },
  });

  crtMaterial.uniforms.tMap.value = connectScreen.texture;

  window.addEventListener('langchange', () => {
    firstScreen.redraw();
    updateLoaderText(shownLoadPct);
  });

  // ==========================================================================
  // LIGHTS & ~260 ADDITIVE DUST PARTICLES
  // ==========================================================================
  const oldLampPos = new THREE.Vector3(-0.56, 1.24, -0.88);
  const newLampPos = new THREE.Vector3(-0.56, 1.33, -0.94);
  const oldLampTarget = new THREE.Vector3(0.0, 0.78, -0.92);
  const newLampTarget = new THREE.Vector3(0.0, 0.85, -0.96);

  // Single shadow-casting light (Requirement 3: limit shadow-casting lights to 1-2)
  const deskSpot = new THREE.SpotLight(0xff9a45, 3.4, 5.5, 0.95, 0.75, 1.2);
  deskSpot.position.copy(oldLampPos);
  deskSpot.target.position.copy(oldLampTarget);
  deskSpot.castShadow = !isSoftwareGl && qualityTier > 0;
  deskSpot.shadow.mapSize.set(isPhone() || isWeakGpu ? 512 : 1024, isPhone() || isWeakGpu ? 512 : 1024);
  deskSpot.shadow.bias = -0.0005;
  deskSpot.shadow.normalBias = 0.02;
  deskSpot.shadow.camera.near = 0.15;
  deskSpot.shadow.camera.far = 4.0;
  scene.add(deskSpot);
  scene.add(deskSpot.target);

  // 2. Cold moon DirectionalLight (#7fa6ff, 1.6) through window
  const moonLight = new THREE.DirectionalLight(0x7fa6ff, 1.6);
  moonLight.position.set(-2.8, 2.3, -0.25);
  moonLight.target.position.set(0.2, 0.7, -0.95);
  moonLight.castShadow = false;
  scene.add(moonLight);
  scene.add(moonLight.target);

  // 3. Very low HemisphereLight
  const hemiSkyWarm = new THREE.Color(0x282238);
  const hemiSkyCool = new THREE.Color(0x2b3b68);
  const hemiGndWarm = new THREE.Color(0x120e1a);
  const hemiGndCool = new THREE.Color(0x0b1020);
  const hemiLight = new THREE.HemisphereLight(0x282238, 0x120e1a, 0.42);
  scene.add(hemiLight);

  // 4. Accent LED-strip SpotLight behind desk that fades in with the modern era
  const ledSpot = new THREE.SpotLight(0x7c5cff, 0.0, 4.2, 1.25, 0.85, 1.2);
  ledSpot.position.set(0, 0.85, -1.22);
  ledSpot.target.position.set(0, 1.75, -1.32);
  scene.add(ledSpot);
  scene.add(ledSpot.target);

  // 5. ~260 additive dust points drifting on sin/cos
  const DUST_COUNT = 260;
  const dustGeom = new THREE.BufferGeometry();
  const dustPos = new Float32Array(DUST_COUNT * 3);
  const dustSeeds = new Float32Array(DUST_COUNT * 3);
  for (let i = 0; i < DUST_COUNT; i++) {
    dustPos[i * 3] = (Math.random() - 0.5) * 3.4;
    dustPos[i * 3 + 1] = 0.25 + Math.random() * 2.1;
    dustPos[i * 3 + 2] = -1.2 + Math.random() * 2.4;
    dustSeeds[i * 3] = Math.random() * Math.PI * 2;
    dustSeeds[i * 3 + 1] = 0.3 + Math.random() * 0.7;
    dustSeeds[i * 3 + 2] = dustPos[i * 3 + 1];
  }
  dustGeom.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
  const dustMat = new THREE.PointsMaterial({
    color: 0xffcfa0,
    size: 0.018,
    transparent: true,
    opacity: 0.42,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const dustPoints = new THREE.Points(dustGeom, dustMat);
  scene.add(dustPoints);

  // ==========================================================================
  // POST-PROCESSING COMPOSER
  // ==========================================================================
  const composer = new EffectComposer(renderer);
  const renderPass = new RenderPass(scene, camera);
  composer.addPass(renderPass);

  let gtaoPass = null;
  if (!isPhone() && !isSoftwareGl) {
    try {
      gtaoPass = new GTAOPass(scene, camera, VW(), VH());
      gtaoPass.output = GTAOPass.OUTPUT.Default;
      gtaoPass.enabled = qualityTier >= 2;
      composer.addPass(gtaoPass);
    } catch (e) {
      gtaoPass = null;
    }
  }

  const BASE_BLOOM_STRENGTH = 0.62;
  const bloomPass = new UnrealBloomPass(new THREE.Vector2(VW(), VH()), BASE_BLOOM_STRENGTH, 0.6, 0.93);
  bloomPass.enabled = qualityTier >= 1 && !isSoftwareGl;
  composer.addPass(bloomPass);

  const outputPass = new OutputPass();
  composer.addPass(outputPass);

  const filmPass = new ShaderPass(FilmShader);
  filmPass.uniforms.uResolution.value.set(VW(), VH());
  composer.addPass(filmPass);

  // ==========================================================================
  // CAMERA POSES (CLOSE, WIDE, CLOSE_M) & PARALLAX
  // ==========================================================================
  const poseClose = {
    pos: new THREE.Vector3(),
    target: new THREE.Vector3(),
    fov: 38,
  };
  const poseWide = {
    pos: new THREE.Vector3(),
    target: new THREE.Vector3(),
    fov: 45,
  };
  const poseCloseM = {
    pos: new THREE.Vector3(),
    target: new THREE.Vector3(),
    fov: 30,
  };
  const wideCameraHelper = new THREE.PerspectiveCamera(45, VW() / VH(), 0.08, 25);

  function computeCameraPoses() {
    const w = VW();
    const h = VH();
    const aspect = w / Math.max(1, h);

    // 1. CLOSE shot on old CRT screen
    const sSize = room.oldScreenSize;
    const sCenter = room.oldScreenCenter;
    const closeFov = 38;
    const tanHalfClose = Math.tan(THREE.MathUtils.degToRad(closeFov * 0.5));
    let closeD;
    let shiftX = 0;
    if (aspect < 0.8) {
      const fitMult = entered ? 1.28 : 1.08;
      closeD = (sSize.x * fitMult) / (aspect * 2 * tanHalfClose);
      shiftX = -0.062 * sSize.x;
    } else {
      closeD = Math.max(sSize.y / 0.78, sSize.x / (0.9 * aspect)) / (2 * tanHalfClose);
    }
    poseClose.fov = closeFov;
    poseClose.pos.set(sCenter.x + shiftX, sCenter.y, sCenter.z + closeD);
    poseClose.target.set(sCenter.x + shiftX, sCenter.y, sCenter.z);

    // 2. WIDE shot
    const isPortraitPhone = aspect < 0.85;
    const hFovDeg = isPortraitPhone ? 82 : 62;
    const hFovRad = THREE.MathUtils.degToRad(hFovDeg);
    const vFovRad = 2 * Math.atan(Math.tan(hFovRad * 0.5) / aspect);
    const vFovDeg = clamp(THREE.MathUtils.radToDeg(vFovRad), 35, 74);

    poseWide.fov = vFovDeg;
    if (isPortraitPhone) {
      poseWide.pos.set(0, 1.32, 1.28);
      poseWide.target.set(0, 1.13, -1.45);
    } else {
      poseWide.pos.set(0, 1.36, 1.62);
      poseWide.target.set(0, 1.22, -1.3);
    }

    wideCameraHelper.fov = poseWide.fov;
    wideCameraHelper.aspect = aspect;
    wideCameraHelper.position.copy(poseWide.pos);
    wideCameraHelper.lookAt(poseWide.target);
    wideCameraHelper.updateProjectionMatrix();
    wideCameraHelper.updateMatrixWorld(true);

    // 3. CLOSE_M shot on modern monitor SCREEN_modern
    const msSize = room.modernScreenSize;
    const msCenter = room.modernScreenCenter;
    const closeMFov = 30;
    const tM = 2 * Math.tan(THREE.MathUtils.degToRad(closeMFov * 0.5));
    let closeMD;
    if (aspect < 0.85) {
      closeMD = msSize.x / 2.3 / aspect / tM;
    } else {
      closeMD = Math.max(msSize.y / 0.94, msSize.x / (0.96 * aspect)) / tM;
    }
    poseCloseM.fov = closeMFov;
    poseCloseM.pos.set(msCenter.x, msCenter.y, msCenter.z + closeMD);
    poseCloseM.target.copy(msCenter);
  }

  computeCameraPoses();

  // ==========================================================================
  // WALL TEXT & STORY OS LAYER
  // ==========================================================================
  const wallStage = document.getElementById('wall-stage');
  const wallText = createWallTextManager({
    stageEl: wallStage,
    getWideCamera: () => wideCameraHelper,
    getScreenSize: () => ({ width: VW(), height: VH() }),
    roomInfo: room,
  });
  wallText.layoutFromWideShot();

  let hintTimeout = null;
  function showHintPill(mode, durationMs = 4000) {
    if (!hintPill || !hintText) return;
    const key =
      mode === 'hold'
        ? 'ui.hint.hold'
        : mode === 'button'
        ? 'ui.hint.button'
        : 'ui.hint.scroll';
    hintText.setAttribute('data-i18n', key);
    const pair = window.I18N_STRINGS?.[key];
    if (pair) {
      hintText.textContent = window.__LANG === 'fil' ? pair[1] : pair[0];
    }
    hintPill.classList.add('visible');
    if (hintTimeout) clearTimeout(hintTimeout);
    if (durationMs > 0) {
      hintTimeout = window.setTimeout(() => {
        hintPill.classList.remove('visible');
      }, durationMs);
    }
  }

  function scrollToPv(targetPv, instant = false) {
    const y = (targetPv / 100) * window.innerHeight;
    window.scrollTo({
      top: y,
      behavior: instant || isReducedMotion() ? 'auto' : 'smooth',
    });
  }

  const osMount = document.getElementById('os-mount');
  const osLayer = createOsLayer({
    mountEl: osMount,
    modernScreenMesh: room.modernScreen,
    camera,
    getScreenSize: () => ({ width: VW(), height: VH() }),
    isReducedMotion,
    sfx,
    riser,
    onScrollToPv: (pvTarget) => scrollToPv(pvTarget, false),
    onShowHint: (mode, dur) => showHintPill(mode, dur),
  });

  // ==========================================================================
  // SCROLL GATING AT INPUT (Wheel, Touchmove, Keydown)
  // ==========================================================================
  let progressPv = 0;
  let targetPv = 0;

  function getFrozenPv() {
    if (paramMod !== null && !Number.isNaN(paramMod)) {
      return lerp(TIMELINE.modPv[0], TIMELINE.modPv[1], clamp(paramMod, 0, 1));
    }
    if (paramV !== null && !Number.isNaN(paramV)) return clamp(paramV, 0, TOTAL_STORY_VH + 120);
    if (paramP !== null && !Number.isNaN(paramP)) return clamp(paramP, 0, 1) * TOTAL_STORY_VH;
    return null;
  }

  window.addEventListener(
    'wheel',
    (e) => {
      if (!entered) {
        e.preventDefault();
        return;
      }
      if (e.deltaY <= 0) return;
      const firstGate = getFirstUnfinishedGate(osLayer.gates);
      if (!firstGate) return;
      const limitPx = ((firstGate.at + 3) / 100) * window.innerHeight;
      if (window.scrollY + e.deltaY > limitPx) {
        e.preventDefault();
        window.scrollTo(0, (firstGate.at / 100) * window.innerHeight);
        osLayer.nudge();
      }
    },
    { passive: false }
  );

  let touchStartY = 0;
  window.addEventListener(
    'touchstart',
    (e) => {
      if (e.touches && e.touches.length > 0) {
        touchStartY = e.touches[0].clientY;
      }
    },
    { passive: true }
  );

  window.addEventListener(
    'touchmove',
    (e) => {
      if (!entered) {
        e.preventDefault();
        return;
      }
      if (!e.touches || e.touches.length === 0) return;
      const dy = touchStartY - e.touches[0].clientY;
      if (dy <= 0) return;
      const firstGate = getFirstUnfinishedGate(osLayer.gates);
      if (!firstGate) return;
      const limitPx = (firstGate.at / 100) * window.innerHeight;
      if (window.scrollY >= limitPx - 2) {
        e.preventDefault();
        window.scrollTo(0, limitPx);
        osLayer.nudge();
      }
    },
    { passive: false }
  );

  window.addEventListener('keydown', (e) => {
    if (!entered) return;
    if (e.target !== document.body && e.target !== document.documentElement) return;
    if (e.key === 'ArrowDown' || e.key === 'PageDown' || e.key === ' ') {
      const firstGate = getFirstUnfinishedGate(osLayer.gates);
      if (!firstGate) return;
      const limitPx = (firstGate.at / 100) * window.innerHeight;
      if (window.scrollY >= limitPx - 10) {
        e.preventDefault();
        window.scrollTo(0, limitPx);
        osLayer.nudge();
      }
    }
  });

  // ==========================================================================
  // SKIP, REPLAY, TOP LOGO & DEEP LINKS
  // ==========================================================================
  function enterStoryRoom() {
    if (entered) return;
    entered = true;
    document.body.classList.add('entered');
    crtMaterial.uniforms.tMap.value = firstScreen.texture;
    crtMaterial.uniforms.power.value = 1.0;
    computeCameraPoses();
    showHintPill('scroll', 5000);
  }

  function skipEntireStory() {
    enterStoryRoom();
    osLayer.skipAll();
    if (contentEl) {
      contentEl.scrollIntoView({ behavior: isReducedMotion() ? 'auto' : 'smooth' });
    }
  }

  function replayStory() {
    window.scrollTo(0, 0);
    progressPv = 0;
    targetPv = 0;
    window.setTimeout(() => {
      osLayer.reset();
      room.setActiveEra(false);
      renderer.shadowMap.needsUpdate = true;
      document.body.classList.remove('at-end', 'past-story', 'content-covered');
      showHintPill('scroll', 4500);
    }, 50);
  }

  if (skipBtn) {
    skipBtn.addEventListener('click', () => {
      sfx('click', 0.25);
      skipEntireStory();
    });
  }

  if (replayBtn) {
    replayBtn.addEventListener('click', () => {
      sfx('click', 0.25);
      replayStory();
    });
  }

  if (logoTopLink) {
    logoTopLink.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: isReducedMotion() ? 'auto' : 'smooth' });
    });
  }

  // Handle deep links (#about, #numbers, #work, #contact, #content) or ?nostory
  const hash = window.location.hash;
  const isDeepLink =
    paramNoStory ||
    ['#about', '#numbers', '#work', '#contact', '#content'].includes(hash);

  // If frozen testing query param (?mod=, ?v=, or ?p=) is used, configure gates to match target position
  const frozenPv = getFrozenPv();
  if (frozenPv !== null) {
    enterStoryRoom();
    if (paramSkin === 2) {
      osLayer.hold.h = 1.25;
    } else if (paramSkin === 3) {
      osLayer.gates.hold.done = true;
      osLayer.hold.h = 2;
    }
    if (frozenPv > OS_TIMES.gates.hold.at + 2) {
      osLayer.gates.hold.done = true;
      osLayer.hold.h = 2;
    }
    if (frozenPv > OS_TIMES.gates.statement.at + 2) {
      osLayer.gates.statement.done = true;
    }
    if (frozenPv > OS_TIMES.gates.error.at + 2) {
      osLayer.gates.error.done = true;
    }
    if (frozenPv > OS_TIMES.gates.success.at + 2) {
      osLayer.gates.success.done = true;
    }
    progressPv = frozenPv;
    targetPv = frozenPv;
  } else {
    window.scrollTo(0, 0);
  }

  // ==========================================================================
  // SHADER PRE-COMPILATION & TEXTURE UPLOAD BEHIND LOADER (WITH TIER-0 RETRY)
  // ==========================================================================
  realLoadPct = 97;
  updateLoaderText(97);

  function uploadAndPrecompileShaders() {
    shaderCompileFailed = false;
    const glCtx = renderer.getContext();
    if (glCtx && glCtx.isContextLost()) {
      throw new Error('WebGL context lost during precompile');
    }

    // Upload textures to GPU
    if (renderer.initTexture) {
      renderer.initTexture(firstScreen.texture);
      renderer.initTexture(connectScreen.texture);
      renderer.initTexture(modernScreenTex);
      if (cardUniforms.uCardTex.value) {
        renderer.initTexture(cardUniforms.uCardTex.value);
      }
    }

    camera.position.copy(poseWide.pos);
    camera.lookAt(poseWide.target);
    camera.updateMatrixWorld(true);

    // 1. Compile and warm up era 0 (with dissolve & collapse active)
    cardUniforms.uMod.value = 0.2;
    cardUniforms.uDissolve.value = 0.5;
    crtMaterial.uniforms.uCollapseY.value = 0.8;
    crtMaterial.uniforms.uCollapseX.value = 0.3;
    room.setActiveEra(false);
    renderer.compile(scene, camera);
    renderer.shadowMap.needsUpdate = renderer.shadowMap.enabled;
    renderer.render(scene, camera);

    // 2. Compile and warm up era 0.5 (with arrive & boot active)
    cardUniforms.uMod.value = 0.65;
    cardUniforms.uDissolve.value = 0.0;
    cardUniforms.uArrive.value = 0.5;
    cardUniforms.uBoot.value = 0.5;
    room.setActiveEra(true);
    renderer.compile(scene, camera);
    renderer.shadowMap.needsUpdate = renderer.shadowMap.enabled;
    renderer.render(scene, camera);

    // 3. Reset back to initial state and bake initial shadow map once
    cardUniforms.uMod.value = 0.0;
    cardUniforms.uDissolve.value = 0.0;
    cardUniforms.uArrive.value = 0.0;
    cardUniforms.uBoot.value = 0.0;
    crtMaterial.uniforms.uCollapseY.value = 0.0;
    crtMaterial.uniforms.uCollapseX.value = 0.0;
    room.setActiveEra(false);
    renderer.shadowMap.needsUpdate = renderer.shadowMap.enabled;
    renderer.render(scene, camera);

    if (shaderCompileFailed) {
      throw new Error('Shader validation or compilation failed');
    }
  }

  // Requirement 5: Wrap shader precompile in try/catch; on failure retry once at quality tier 0
  try {
    uploadAndPrecompileShaders();
  } catch (precompileErr) {
    if (paramDebug) {
      console.warn('[WebGL Debug] Precompile failed, retrying at Quality Tier 0:', precompileErr);
    }
    try {
      qualityTier = 0;
      if (gtaoPass) gtaoPass.enabled = false;
      bloomPass.enabled = false;
      renderer.shadowMap.enabled = false;
      deskSpot.castShadow = false;
      scene.environment = null;
      room.downgradeToSimpleMaterials();

      shaderCompileFailed = false;
      room.setActiveEra(false);
      renderer.compile(scene, camera);
      renderer.render(scene, camera);
      if (shaderCompileFailed) {
        throw new Error('Tier 0 fallback shader compilation failed');
      }
    } catch (fallbackErr) {
      showLoaderFailureMessage(
        'Graphics initialization failed on this device. Please refresh or try another browser.',
        'Hindi ma-initialize ang graphics sa device na ito. Paki-refresh.'
      );
      return;
    }
  }

  // Requirement 6: Handle webglcontextlost and webglcontextrestored
  let isContextLost = false;
  canvas.addEventListener(
    'webglcontextlost',
    (e) => {
      e.preventDefault();
      isContextLost = true;
      if (paramDebug) {
        console.warn('[WebGL Debug] webglcontextlost — pausing render loop');
      }
    },
    false
  );

  canvas.addEventListener(
    'webglcontextrestored',
    async () => {
      if (paramDebug) {
        console.info('[WebGL Debug] webglcontextrestored — rebuilding GPU resources');
      }
      try {
        buildEnvironmentMap();
        firstScreen.texture.needsUpdate = true;
        connectScreen.texture.needsUpdate = true;
        modernScreenTex.needsUpdate = true;
        if (cardUniforms.uCardTex.value) {
          cardUniforms.uCardTex.value.needsUpdate = true;
        }
        if (room && room.root) {
          scene.remove(room.root);
        }
        room = await buildOrLoadRoom({
          scene,
          crtMaterial,
          modernScreenTexture: modernScreenTex,
          isPhone: isPhone(),
          isWeakGpu,
          maxTextures: renderer.capabilities.maxTextures || maxTexImageUnits,
          useAlphaFade: isPhone() || isReducedMotion(),
        });
        uploadAndPrecompileShaders();
        isContextLost = false;
        lastFrameTime = performance.now();
        requestAnimationFrame(tick);
      } catch (restoreErr) {
        showLoaderFailureMessage();
      }
    },
    false
  );

  realLoadPct = 100;

  if (isDeepLink) {
    shownLoadPct = 100;
    updateLoaderText(100);
    document.body.classList.add('ready');
    skipEntireStory();
    const targetBlock = document.querySelector(hash) || contentEl;
    if (targetBlock) {
      window.setTimeout(() => targetBlock.scrollIntoView(), 50);
    }
  } else if (frozenPv !== null || params.has('connect')) {
    shownLoadPct = 100;
    updateLoaderText(100);
    document.body.classList.add('ready');
  }

  // ==========================================================================
  // MOUSE PARALLAX & RESIZE HANDLING
  // ==========================================================================
  const mouse = { x: 0, y: 0, tx: 0, ty: 0 };
  const isFinePointer = window.matchMedia('(pointer: fine)').matches;

  if (isFinePointer) {
    window.addEventListener(
      'pointermove',
      (e) => {
        mouse.tx = (e.clientX / Math.max(1, VW())) * 2 - 1;
        mouse.ty = (e.clientY / Math.max(1, VH())) * 2 - 1;
      },
      { passive: true }
    );
  }

  let lastCanvasW = VW();
  let lastCanvasH = VH();

  window.addEventListener('resize', () => {
    const w = VW();
    const h = VH();
    if (w === lastCanvasW && h === lastCanvasH) return;
    lastCanvasW = w;
    lastCanvasH = h;

    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();

    renderer.setSize(w, h, false);
    composer.setSize(w, h);
    filmPass.uniforms.uResolution.value.set(w, h);

    computeCameraPoses();
    wallText.layoutFromWideShot();

    if (isSoftwareGl || qualityTier === 0) {
      renderer.render(scene, camera);
    } else {
      composer.render();
    }
  });

  // ==========================================================================
  // ADAPTIVE QUALITY & BAR COLOR SAMPLING
  // ==========================================================================
  let slowFrameCount = 0;
  let smoothTimeAccum = 0;
  let stepUpCount = 0;
  let lastBarSampleAt = 0;

  function sampleBottomBarColor(now) {
    if (customBarColor || now - lastBarSampleAt < 400) return;
    lastBarSampleAt = now;
    const hex = `#${currentFogColor.getHexString()}`;
    const meta = document.getElementById('theme-color-meta');
    if (meta) meta.setAttribute('content', hex);
    document.documentElement.style.backgroundColor = hex;
  }

  // Pre-allocated scratch vectors for 0-GC render loop
  const camPos = new THREE.Vector3();
  const camTarget = new THREE.Vector3();
  const wideMixPos = new THREE.Vector3();
  const wideMixTarget = new THREE.Vector3();
  const warmLampColor = new THREE.Color(0xff9a45);
  const coolLampColor = new THREE.Color(0xc8dcff);
  const warmDustColor = new THREE.Color(0xffcfa0);
  const coolDustColor = new THREE.Color(0x9ec5ff);

  let lastFrameTime = performance.now();
  let elapsedTotal = 0;
  let currentActiveEraIsNew = false;
  let currentBothVisible = false;
  let stableFrames = 0;
  const bootStartAt = performance.now();

  // Transition state trackers for ~300ms phosphor afterglow, ~400ms blank-beat pulse, SFX hysteresis, and aria-live
  let crtAfterglow = 0.0;
  let blankPulseTimer = 0.0;
  let eraAnnounced = false;
  const initialModVal = frozenPv !== null ? computeTimelineState(frozenPv, paramMod).mod : 0;
  let prevMod = initialModVal;
  let sfxPowerSide = initialModVal >= 0.02 ? 1 : -1;
  let sfxWhooshSide = initialModVal >= 0.32 ? 1 : -1;
  let sfxBootSide = initialModVal >= 0.81 ? 1 : -1;

  function updateTransitionTriggers(mod, dt) {
    // 1. Accessibility aria-live announcement once when transition starts
    if (mod >= 0.015 && !eraAnnounced) {
      eraAnnounced = true;
      if (eraAnnouncer) {
        const pair = window.I18N_STRINGS?.['ui.era.modern'];
        eraAnnouncer.textContent = pair
          ? window.__LANG === 'fil'
            ? pair[1]
            : pair[0]
          : 'Switching to the modern setup';
      }
    } else if (mod <= 0.002 && eraAnnounced) {
      eraAnnounced = false;
      if (eraAnnouncer) eraAnnouncer.textContent = '';
    }

    // 2. Direction-crossing SFX with hysteresis (skip when frozen via query params)
    if (frozenPv === null && entered) {
      // Power-down thunk around mod 0.02 (hysteresis 0.005 .. 0.08)
      if (sfxPowerSide <= 0 && mod >= 0.025 && prevMod < 0.025) {
        sfxPowerSide = 1;
        sfx('powerdown', 0.22);
      } else if (sfxPowerSide >= 0 && mod <= 0.075 && prevMod > 0.075) {
        sfxPowerSide = -1;
        sfx('powerdown', 0.18);
      } else if (mod < 0.005) {
        sfxPowerSide = -1;
      } else if (mod > 0.12) {
        sfxPowerSide = 1;
      }

      // Blank-beat low whoosh around mod 0.32 (hysteresis 0.26 .. 0.48)
      if (sfxWhooshSide <= 0 && mod >= 0.32 && prevMod < 0.32) {
        sfxWhooshSide = 1;
        blankPulseTimer = 0.4; // 400ms bloom pulse
        sfx('whoosh', 0.21);
      } else if (sfxWhooshSide >= 0 && mod <= 0.46 && prevMod > 0.46 && mod >= 0.3) {
        sfxWhooshSide = -1;
        blankPulseTimer = 0.4;
        sfx('whoosh', 0.18);
      } else if (mod < 0.25) {
        sfxWhooshSide = -1;
      } else if (mod > 0.54) {
        sfxWhooshSide = 1;
      }

      // Boot chime around mod 0.81 (hysteresis 0.75 .. 0.89)
      if (sfxBootSide <= 0 && mod >= 0.81 && prevMod < 0.81) {
        sfxBootSide = 1;
        sfx('boot', 0.22);
      } else if (sfxBootSide >= 0 && mod <= 0.88 && prevMod > 0.88 && mod >= 0.78) {
        sfxBootSide = -1;
        sfx('boot', 0.18);
      } else if (mod < 0.74) {
        sfxBootSide = -1;
      } else if (mod > 0.94) {
        sfxBootSide = 1;
      }
    }

    // 3. ~300ms CRT phosphor afterglow decay
    if (!isReducedMotion()) {
      if (mod > 0.01 && mod < 0.098) {
        crtAfterglow = Math.max(crtAfterglow, 0.65 * Math.sin(range(mod, 0.0, 0.1) * Math.PI));
      } else {
        crtAfterglow = Math.max(0.0, crtAfterglow - dt / 0.3);
      }
      if (blankPulseTimer > 0) {
        blankPulseTimer = Math.max(0.0, blankPulseTimer - dt);
      }
    } else {
      crtAfterglow = 0.0;
      blankPulseTimer = 0.0;
    }

    prevMod = mod;
  }

  function afterDraw(cb) {
    const gl = renderer.getContext();
    if (gl && typeof gl.fenceSync === 'function') {
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          window.setTimeout(cb, 80);
        }
      };
      window.setTimeout(poll, 5);
    } else {
      window.setTimeout(cb, 80);
    }
  }

  function tick(now = performance.now()) {
    if (isContextLost) return;
    const rawDt = Math.max(0.001, (now - lastFrameTime) / 1000);
    const dt = Math.min(0.1, rawDt);
    lastFrameTime = now;
    elapsedTotal += dt;

    // 1. Apply any pending DPR change at the START of the frame before drawing
    if (pendingDpr !== null) {
      currentDpr = pendingDpr;
      pendingDpr = null;
      renderer.setPixelRatio(currentDpr);
      composer.setSize(VW(), VH());
    }

    // 2. Loader progression & stability check
    if (!document.body.classList.contains('ready')) {
      loaderGlowPos.x += (loaderGlowPos.tx - loaderGlowPos.x) * 0.12;
      loaderGlowPos.y += (loaderGlowPos.ty - loaderGlowPos.y) * 0.12;
      if (loaderGlow) {
        loaderGlow.style.left = `${loaderGlowPos.x.toFixed(1)}px`;
        loaderGlow.style.top = `${loaderGlowPos.y.toFixed(1)}px`;
      }

      if (shownLoadPct < realLoadPct) {
        shownLoadPct = Math.min(realLoadPct, shownLoadPct + Math.max(1.2, dt * 42));
        updateLoaderText(shownLoadPct);
      }

      if (realLoadPct >= 100 && shownLoadPct >= 99.5) {
        if (rawDt < 0.034 || isSoftwareGl) {
          stableFrames++;
        } else {
          stableFrames = Math.max(0, stableFrames - 1);
        }
        if (stableFrames >= 20 || now - bootStartAt > 2500 || isSoftwareGl) {
          shownLoadPct = 100;
          updateLoaderText(100);
          document.body.classList.add('ready');
        }
      }
    }

    // 3. Check if #content completely covers the room (its top <= 0)
    if (contentEl) {
      const cRect = contentEl.getBoundingClientRect();
      const isPastStory = cRect.top < window.innerHeight * 0.6;
      headerEl?.classList.toggle('past-story', isPastStory);
      document.body.classList.toggle('past-story', isPastStory);

      if (cRect.top <= 0 && frozenPv === null) {
        if (canvas.style.visibility !== 'hidden') {
          canvas.style.visibility = 'hidden';
          document.body.classList.add('content-covered');
        }
        if (isSoftwareGl) afterDraw(tick);
        else requestAnimationFrame(tick);
        return;
      } else if (canvas.style.visibility === 'hidden') {
        canvas.style.visibility = 'visible';
        document.body.classList.remove('content-covered');
      }
    }

    headerEl?.classList.toggle('scrolled', window.scrollY > 20);

    // 4. Opening CRT Connect Screen & Tube Flicker Transition
    if (!entered) {
      connectScreen.update(dt);
      if (tubeFlickerStart > 0) {
        const sinceConnect = (now - tubeFlickerStart) / 1000;
        if (sinceConnect >= 1.1 && sinceConnect < 1.75) {
          const flkT = (sinceConnect - 1.1) / 0.65;
          if (flkT < 0.22) {
            crtMaterial.uniforms.power.value = 0.05;
          } else {
            crtMaterial.uniforms.tMap.value = firstScreen.texture;
            crtMaterial.uniforms.power.value = lerp(0.05, 1.0, (flkT - 0.22) / 0.78);
          }
        } else if (sinceConnect >= 1.75) {
          enterStoryRoom();
        }
      }
    }

    // 5. Compute & Gate Story Scroll Position pv (in vh)
    const fPv = getFrozenPv();
    if (fPv !== null) {
      targetPv = fPv;
      progressPv = fPv;
    } else if (entered) {
      const rawPv = (window.scrollY / Math.max(1, window.innerHeight)) * 100;
      const firstGate = getFirstUnfinishedGate(osLayer.gates);
      if (firstGate && !osLayer.isHolding() && rawPv > firstGate.at + 3) {
        window.scrollTo(0, (firstGate.at / 100) * window.innerHeight);
      }
      targetPv = limitScrollPv(rawPv, osLayer.gates);
      progressPv += (targetPv - progressPv) * (1 - Math.exp(-dt * 5));

      if (rawPv > 18 && hintPill?.classList.contains('visible') && !firstGate) {
        hintPill.classList.remove('visible');
      }
    } else {
      targetPv = 0;
      progressPv = 0;
    }

    const tState = computeTimelineState(progressPv, paramMod);
    document.body.classList.toggle('at-end', tState.atEnd);

    const rm = isReducedMotion();
    const phone = isPhone();
    updateTransitionTriggers(tState.mod, dt);

    // 6. Update Cardboard & 5-Stage Era Transition Uniforms
    cardUniforms.uReveal.value = tState.uReveal;
    cardUniforms.uCardFloor.value = tState.uCardFloor;
    cardUniforms.uMod.value = tState.mod;
    cardUniforms.uWaveA.value = tState.waveA;
    cardUniforms.uWaveB.value = tState.waveB;
    cardUniforms.uDissolve.value = tState.uDissolve;
    cardUniforms.uArrive.value = tState.uArrive;
    cardUniforms.uBoot.value = rm ? smoothstepSimple(0.2, 0.8, tState.mod) : tState.uBoot;
    cardUniforms.uSimpleFade.value = phone || rm ? 1.0 : 0.0;
    cardUniforms.uReduceMotion.value = rm ? 1.0 : 0.0;

    // Swap Era Meshes & Re-bake Shadows ONCE when era flips at mod = 0.5
    const wantBothVisible = rm && tState.mod > 0.15 && tState.mod < 0.85;
    if (tState.isNewEra !== currentActiveEraIsNew || wantBothVisible !== currentBothVisible) {
      const eraFlipped = tState.isNewEra !== currentActiveEraIsNew;
      currentActiveEraIsNew = tState.isNewEra;
      currentBothVisible = wantBothVisible;
      room.setActiveEra(currentActiveEraIsNew, currentBothVisible);
      if (eraFlipped && renderer.shadowMap.enabled) {
        renderer.shadowMap.needsUpdate = true;
      }
    }

    // Phase 1 POWER-DOWN (mod 0.00 - 0.10): CRT collapse & ~300ms phosphor afterglow
    if (rm) {
      crtMaterial.uniforms.uCollapseY.value = 0.0;
      crtMaterial.uniforms.uCollapseX.value = 0.0;
      crtMaterial.uniforms.uAfterglow.value = 0.0;
      if (room.oldScreen) {
        room.oldScreen.visible = tState.mod < 0.8;
      }
      if (entered) {
        crtMaterial.uniforms.power.value = Math.max(0, 1 - range(tState.mod, 0.2, 0.8));
      }
    } else {
      crtMaterial.uniforms.uCollapseY.value = tState.collapseY;
      crtMaterial.uniforms.uCollapseX.value = tState.collapseX;
      crtMaterial.uniforms.uAfterglow.value = crtAfterglow;
      if (room.oldScreen) {
        room.oldScreen.visible = tState.mod < 0.1 || crtAfterglow > 0.01;
      }
      const basePower =
        (1 - 0.25 * tState.wall1In * (1 - tState.wall1Out)) * tState.crtPowerFade;
      if (entered) {
        crtMaterial.uniforms.power.value = Math.max(0, basePower);
      }
    }

    // Keep SCREEN_modern, LED_WALL_WASH, and NEON_LOGO locked to ARRIVE scale/fade (mod 0.50 - 0.80)
    if (room.modernScreen) {
      const mDelay = room.modernScreen.userData.eraDelay || 0.04;
      const localArr = clamp((tState.uArrive - mDelay * 0.42) / 0.58, 0, 1);
      if (!rm && tState.mod >= 0.5 && localArr <= 0.01) {
        room.modernScreen.visible = false;
      } else if (tState.mod >= 0.5 || wantBothVisible) {
        room.modernScreen.visible = true;
        if (!rm && !phone && tState.uArrive < 0.999) {
          const sc = lerp(0.92, 1.0, easeOutBack(localArr));
          room.modernScreen.scale.set(sc, sc, sc);
        } else {
          room.modernScreen.scale.set(1, 1, 1);
        }
      }
    }
    if (room.ledWallWash && room.ledWallWash.material) {
      room.ledWallWash.material.opacity = rm
        ? range(tState.mod, 0.2, 0.8)
        : smoothstepSimple(0.15, 0.95, tState.uArrive);
    }
    if (room.neonLogo && room.neonLogo.material) {
      const nDelay = room.neonLogo.userData.eraDelay || 0.55;
      const nArr = clamp((tState.uArrive - nDelay * 0.42) / 0.58, 0, 1);
      room.neonLogo.material.opacity = rm ? range(tState.mod, 0.2, 0.8) : smoothstepSimple(0.1, 0.95, nArr);
    }
    if (room.clockLed && room.clockLed.material) {
      const clockCardCover =
        !rm && tState.mod > 0.05 && tState.mod < 0.72
          ? smoothstepSimple(0.06, 0.22, tState.mod) * (1 - smoothstepSimple(0.54, 0.7, tState.mod))
          : 0;
      room.clockLed.material.opacity = 1 - clockCardCover;
    }

    // 7. Lighting Grade, Old Lamp Flicker & Blank-Beat Pulse
    const kGrade = tState.gradeK;
    deskSpot.color.copy(warmLampColor).lerp(coolLampColor, kGrade);

    let spotBaseIntensity = lerp(3.4, 2.2, kGrade);
    if (!rm && tState.mod > 0 && tState.mod < 0.3) {
      spotBaseIntensity *= lerp(0.32, 1.0, tState.oldLampFlicker);
    }
    if (!rm && tState.blankBell > 0) {
      spotBaseIntensity += 0.55 * tState.blankBell;
    }
    deskSpot.intensity = spotBaseIntensity;
    deskSpot.position.copy(oldLampPos).lerp(newLampPos, kGrade);
    deskSpot.target.position.copy(oldLampTarget).lerp(newLampTarget, kGrade);
    deskSpot.angle = lerp(0.95, 1.15, kGrade);

    if (room.oldLampBulb && room.oldLampBulb.material) {
      room.oldLampBulb.material.emissiveIntensity = rm ? 3.2 : 3.2 * tState.oldLampFlicker;
    }

    hemiLight.color.copy(hemiSkyWarm).lerp(hemiSkyCool, kGrade);
    hemiLight.groundColor.copy(hemiGndWarm).lerp(hemiGndCool, kGrade);
    hemiLight.intensity = lerp(0.42, 0.65, kGrade) + (rm ? 0 : 0.18 * tState.blankBell);
    ledSpot.intensity = tState.ledIntensity;

    // Bloom pulse during BLANK BEAT (+0.3) and BOOT flash (+0.25), disabled in reduced motion
    const timerBloomBoost = blankPulseTimer > 0 ? 0.3 * Math.sin((blankPulseTimer / 0.4) * Math.PI) : 0;
    const totalBloomBoost = rm
      ? 0
      : Math.max(tState.blankBloomDelta, timerBloomBoost) + tState.bootBloomDelta;
    bloomPass.strength = BASE_BLOOM_STRENGTH + totalBloomBoost;

    // Update dust particles & tint
    dustMat.color.copy(warmDustColor).lerp(coolDustColor, kGrade);
    const posAttr = dustGeom.attributes.position;
    for (let i = 0; i < DUST_COUNT; i++) {
      const seed = dustSeeds[i * 3];
      const spd = dustSeeds[i * 3 + 1];
      const baseY = dustSeeds[i * 3 + 2];
      posAttr.array[i * 3 + 1] = baseY + Math.sin(elapsedTotal * spd + seed) * 0.08;
      posAttr.array[i * 3] += Math.cos(elapsedTotal * 0.4 * spd + seed) * 0.0003;
    }
    posAttr.needsUpdate = true;

    // 8. Camera Path, Blank-Beat FOV Push-In (-2 deg), Mouse Parallax & Hold Tension
    wideMixPos.copy(poseClose.pos).lerp(poseWide.pos, tState.pullT);
    wideMixTarget.copy(poseClose.target).lerp(poseWide.target, tState.pullT);
    const wideMixFov = lerp(poseClose.fov, poseWide.fov, tState.pullT);

    camPos.copy(wideMixPos).lerp(poseCloseM.pos, tState.pushZ);
    camTarget.copy(wideMixTarget).lerp(poseCloseM.target, tState.pushZ);
    let activeFov = lerp(wideMixFov, poseCloseM.fov, tState.pushZ);

    // Phase 3 BLANK BEAT tiny camera push-in (FOV -2 deg and return)
    if (!rm) {
      activeFov += tState.blankFovDelta;
    }

    // Smooth mouse parallax
    const mouseLerp = 1 - Math.exp(-dt * 2.6);
    mouse.x += (mouse.tx - mouse.x) * mouseLerp;
    mouse.y += (mouse.ty - mouse.y) * mouseLerp;

    const motionScale = rm ? 0.6 : 1.0;
    const paraK = (0.35 + 0.65 * tState.pullT) * (1 - 0.9 * tState.pushZ) * motionScale;
    camPos.x += mouse.x * 0.22 * paraK;
    camPos.y -= mouse.y * 0.1 * paraK;
    camTarget.x += mouse.x * 0.05 * paraK;
    camTarget.y -= mouse.y * 0.03 * paraK;

    // Hold tension camera FOV tightening & tremble
    const tension = osLayer.getTension();
    if (tension > 0.001 && !rm) {
      activeFov *= 1 - 0.06 * tension;
      camPos.x += (Math.random() - 0.5) * 0.008 * tension;
      camPos.y += (Math.random() - 0.5) * 0.008 * tension;
    }

    camera.fov = activeFov;
    camera.position.copy(camPos);
    camera.lookAt(camTarget);
    camera.rotation.z += -mouse.x * 0.008 * paraK;
    camera.updateProjectionMatrix();
    camera.updateMatrixWorld(true);

    // Haze density & colour lerp
    const distToScreen = Math.max(0.35, camera.position.distanceTo(room.oldScreenCenter));
    scene.fog.density = lerp(0.12 / distToScreen, 0.02, tState.hazeR);
    currentFogColor.copy(hazeBgColor).lerp(nightBgColor, tState.hazeR);

    // 9. Update Wall HTML Headlines & OS Layer
    wallText.update(tState, camera);
    osLayer.update(rawDt, tState);

    // 10. Update Post-Processing Film Uniforms
    const baseBlur = lerp(0.006, 0.0018, tState.pullT);
    filmPass.uniforms.uBlur.value = entered ? baseBlur : baseBlur * 0.15;
    filmPass.uniforms.uWarm.value = 1.0 - kGrade;
    filmPass.uniforms.uTime.value = rm ? 0.0 : elapsedTotal;

    // 11. Render Scene
    if (isSoftwareGl || qualityTier === 0) {
      renderer.render(scene, camera);
    } else {
      composer.render();
    }

    sampleBottomBarColor(now);

    // 12. Adaptive Quality Monitoring (skip when ?q or ?dpr is set or tab is hidden)
    if (paramQ === null && paramDpr === null && !document.hidden && !isSoftwareGl) {
      const frameMs = rawDt * 1000;
      if (frameMs > 21.5) {
        slowFrameCount++;
        smoothTimeAccum = 0;
        if (slowFrameCount >= 45) {
          slowFrameCount = 0;
          if (gtaoPass && gtaoPass.enabled) {
            gtaoPass.enabled = false;
            qualityTier = 1;
          } else if (currentDpr > 0.65 && !phone) {
            pendingDpr = Math.max(0.5, currentDpr * 0.8);
          } else if (bloomPass.enabled) {
            bloomPass.enabled = false;
            qualityTier = 0;
          }
        }
      } else if (frameMs < 17.5) {
        slowFrameCount = Math.max(0, slowFrameCount - 1);
        smoothTimeAccum += rawDt;
        if (smoothTimeAccum >= 4.0 && stepUpCount < 3 && currentDpr < 1.5) {
          smoothTimeAccum = 0;
          stepUpCount++;
          pendingDpr = Math.min(1.5, currentDpr * 1.2);
        }
      }
    }

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      requestAnimationFrame(tick);
    }
  }

  requestAnimationFrame(tick);

  // Clean disposal on page teardown
  window.addEventListener('beforeunload', () => {
    connectScreen.dispose();
    wallText.dispose();
    room.dispose();
    disposeCardboard();
    dustGeom.dispose();
    dustMat.dispose();
    firstScreen.texture.dispose();
    modernScreenTex.dispose();
    crtMaterial.dispose();
    composer.dispose();
    renderer.dispose();
  });
}

function smoothstepSimple(a, b, x) {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}

initPortfolioStory();
