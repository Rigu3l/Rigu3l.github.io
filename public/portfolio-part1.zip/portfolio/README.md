# Rj Verceles — Interactive 3D Portfolio (Part 1: The Interactive 3D Story)

Interactive 3D opening story for **Rj Verceles** (*Full Stack Developer & Web Designer · Zambales*), built with **Vite**, **Vanilla ES Modules**, **Three.js (0.170.x)**, custom GLSL shaders, procedural Web Audio synthesis, and bilingual English/Filipino dictionaries.

---

## 1. Setup & Run Commands

```bash
npm install
npm run dev      # Starts dev server on http://localhost:3000
npm run build    # Builds production bundle into dist/
npm run preview  # Previews production build
```

Run the unit test suite for timeline & scroll-gating logic:

```bash
npx --yes tsx --test src/timeline.test.js
```

---

## 2. Story Timeline Table (`vh` & Normalized Constants)

All timings live in `src/timeline.js` (`CHAPTERS`, `TIMELINE`, `OS_TIMES`, `TRANSITION_CONSTANTS`). Total track height before `#content` is **920 vh**:

| Chapter / Beat | Range (`vh` or `p1`/`mod`) | Behavior & Mechanics |
| :--- | :--- | :--- |
| `screen` (60 vh) & `room` (140 vh) | `pv`: `0 – 200` (`p1 = clamp(pv / 200)`) | Opening CRT close-up -> camera pull-back (`p1: 0.12 – 0.66`), haze clearing (`p1: 0.18 – 0.78`), cardboard-to-real fibrous reveal (`p1: 0.42 – 0.90`, `0 -> 3.2 m`), 10% cardboard floor memory (`p1: 0.70 – 0.95`). |
| Wall Headline 1 | In: `p1 [0.60, 0.76]` (`pv [120, 152]`), Out: `pv [225, 255]` | HTML `<h2 class="wall-copy">` locked to 3D wall anchor `(0, 1.925, -1.28)` above old CRT monitor. |
| `hold` (40 vh) & `modern` (220 vh) | `pv`: `245 – 425` (`mod = range(pv, 245, 425)`) | **5-Beat Old-PC-to-Modern-PC Transition** (`POWER-DOWN`, `RETIRE`, `BLANK BEAT`, `ARRIVE`, `BOOT` — see §3 below). |
| Wall Headline 2 | In: `pv [430, 470]`, Out: `pv [500, 522]` | Second HTML headline projected above `SCREEN_modern`. |
| `push` (70 vh) | `pv`: `510 – 575` | Camera pushes into `CLOSE_M` (FOV 30) framing `SCREEN_modern`. |
| `os` (100 vh) — Hold Gate | `OS_TIMES.in`: `[425, 445]`, `hold`: `{ show: 586, at: 600, next: 602 }` | 2-stage Press-and-Hold (`1.8s` per stage) morphs OS from Skin 1 (pixel art) -> Skin 2 (glossy) -> Skin 3 (flat modern), updating `Canvas 7` to `Canvas 11` with tension, jitter, camera FOV tightening, and stretched audio riser. |
| `dialogs` (90 vh) — 3 Dialogs | `statement`: `{ show: 692, at: 705, next: 719 }`<br>`error`: `{ show: 718, at: 735, next: 749 }`<br>`success`: `{ show: 748, at: 765, next: 830 }` | Armed dialogs (`0.75s` button charge bar). Error dialog triggers red monochrome overlay + `.glitch` shake. Scroll is refused at each unfinished gate with card bounce `nudge()` and hint pill. |
| `exit` (70 vh) & `end` (50 vh) | `OS_TIMES.out`: `[772, 830]`, Finale: `pv >= 815` | Camera pulls back to `WIDE` shot, finale headline & replay button fade in, `#content` paper sheet peeks ~10% and rises over the room at `920 vh`. |

---

## 3. Transition (Old PC to Modern PC Sequence)

The switch from the old CRT setup to the modern workstation spans `pv = 245 – 425 vh` (`mod = 0.00 – 1.00`), is 100% scroll-driven and reversible when scrolling back up, and announces `"Switching to the modern setup"` via `#era-announcer` (`aria-live="polite"`).

### Phase Table (`mod = 0.00 – 1.00`)

| Phase | `mod` Range | Visuals, Shaders & Audio |
| :--- | :--- | :--- |
| **1. POWER-DOWN** | `0.00 – 0.10` | CRT picture collapses like a real tube shutting off: squeezes vertically to a bright horizontal line (`uCollapseY` / `collapseY`: `0.00 – 0.055`), shrinks horizontally to a glowing dot (`uCollapseX` / `collapseX`: `0.045 – 0.090`), and fades (`0.075 – 0.100`) with a `~300 ms` phosphor afterglow (`uAfterglow`). The old desk lamp flickers once and dims; procedural `powerdown` thunk SFX triggers once per direction crossing. |
| **2. RETIRE** | `0.10 – 0.30` | Old PC and desk props (`era = "old"`) dissolve via a dithered threshold noise in the era shader (`noise < uDissolve`, delayed by `aEraD`), with a thin glowing accent edge (`#7C5CFF`) and a `+4.5 cm` upward vertex lift while Cardboard Wave A (`0.02 – 0.30`) travels outward across the room. Phones skip the pixel-dissolve for a lightweight opacity cross-fade. |
| **3. BLANK BEAT** | `0.30 – 0.50` | Quiet moment where the room shows only warm kraft cardboard silhouettes. Bloom strength pulses by `+0.3` (`~400 ms` / peaking at `mod = 0.40`), camera gives a subtle push-in (`FOV -2°`) and returns, and a procedural low `whoosh` SFX plays once per crossing. |
| **4. ARRIVE** | `0.50 – 0.80` | Era meshes swap and shadows re-bake once at `mod = 0.50`. Each modern mesh (`era = "new"`) scales from `0.92` to `1.00` with `easeOutBack` overshoot (delayed by `aEraD` per object as Wave B `0.50 – 0.80` passes them) and fades from cardboard to real materials. A thin accent edge-light sweeps left-to-right across the new monitor's bezel. |
| **5. BOOT** | `0.80 – 1.00` | `SCREEN_modern` turns on (`uBoot = 0..1`): the dark panel brightens with a short bloom flash (`+0.25`), the modern wallpaper fades in, and the `RV` logo scales in from `0.90` to `1.00` with a soft radial glow. A procedural `boot` chime SFX plays once when crossing `0.80`. |

### Transition Constants (`TRANSITION_CONSTANTS` in `src/timeline.js`)

- `powerDownMod`: `[0.00, 0.10]`, `collapseYMod`: `[0.00, 0.055]`, `collapseXMod`: `[0.045, 0.090]`, `crtPowerFadeMod`: `[0.075, 0.10]`, `afterglowMs`: `300`
- `retireMod`: `[0.10, 0.30]`, `retireLiftM`: `0.045`, `dissolveEdgeWidth`: `0.11`, `waveAMod`: `[0.02, 0.30]`
- `blankMod`: `[0.30, 0.50]`, `blankBloomPulse`: `0.30`, `blankPulseMs`: `400`, `blankFovDeltaDeg`: `-2.0`
- `swapMod`: `0.50`, `arriveMod`: `[0.50, 0.80]`, `arriveScaleFrom`: `0.92`, `arriveOvershoot`: `1.70158`, `waveBMod`: `[0.50, 0.80]`
- `bootMod`: `[0.80, 1.00]`, `bootLogoScaleFrom`: `0.90`, `bootBloomPulse`: `0.25`

### Transition Debug Parameter (`?mod=`)

- `?mod=0.35` — Freezes the story at an exact normalized `mod` value (`0.00 – 1.00`, mapped onto `pv = 245 – 425 vh`) and bypasses the connect screen for deterministic visual inspection (e.g., `?mod=0.05`, `?mod=0.15`, `?mod=0.25`, `?mod=0.40`, `?mod=0.60`, `?mod=0.75`, `?mod=0.90`).

---

## 4. Replacing the Procedural Room with a GLB (Naming Convention)

`src/room.js` (`buildOrLoadRoom`) accepts a `glbUrl` (loaded via `GLTFLoader` + `MeshoptDecoder`) with zero code changes if the GLB uses these object names:

- `CRT` (`THREE.Group`): Hero rig group on the desk.
- `SCREEN` (or any mesh starting with `SCREEN` except `SCREEN_modern`): Old-era 4:3 CRT screen mesh receiving the CRT shader & connect-screen texture.
- `SCREEN_modern`: New-era 16:9 monitor panel mesh (`userData.era = "new"`) used to project the `1600x914` OS UI layer.
- `LAMP BULB`: Emissive bulb mesh on the old-era desk lamp (`userData.era = "old"`).
- `NEW_Lamp_bulb`: Emissive bulb mesh on the modern-era desk lamp (`userData.era = "new"`).
- `WINDOW - night sky`: Window backdrop plane mesh.
- Tag old-only props with `userData.era = "old"` and modern-only props with `userData.era = "new"`.

---

## 5. Editing Story Copy & Languages

All bilingual strings (English `en` primary + Filipino `fil` secondary) live in `src/lang.js`:
- `window.STORY_COPY`: Contains `meta` (name, role, location, first-screen chip & 2-line headline), `loader` boot stages (`0 / 25 / 55 / 85 / 96`), `connectPrompt`, `beats` (all 8 story beats), and `wall1` / `wall2` copy.
- `window.I18N_STRINGS`: Key-value pairs applied automatically to `[data-i18n]` and `[data-i18n-aria]` DOM elements via `window.applyLang()`.
- Call `window.L(enString, filString)` anywhere in JS or Canvas drawing code.

---

## 6. Swapping Audio

`src/music.js` synthesizes the ambient pad loop (as an in-memory stereo WAV Blob played by an `HTMLAudioElement` routed through a Web Audio `GainNode` for iOS compatibility) and pre-decodes procedural `AudioBuffer`s for `click`, `start`, `next`, `error`, `done`, `powerdown`, `whoosh`, `boot`, and `riser`. To use external audio files instead, replace `audioEl.src` in `ensureContext()` and decode your `.mp3`/`.wav` files in `buildSfxBuffers()`.

---

## 7. Query Parameters & Performance Notes

- `?mod=0.35` — Freeze the old-to-modern PC transition at a specific `mod` value (`0.00 – 1.00`).
- `?v=300` — Freeze story at a specific `vh` position (e.g., `?v=0`, `?v=140`, `?v=335`, `?v=450`, `?v=600`, `?v=705`, `?v=735`, `?v=765`, `?v=850`).
- `?p=0.5` — Freeze story at a normalized fraction (`0.0 – 1.0`) of the `920 vh` track.
- `?skin=2` — Preview OS Skin 2 (glossy era) when inspecting `?v=600`.
- `?motion=reduce` — Activate calm reduced-motion mode (straight cross-fade between eras, no camera FOV push or bloom pulse).
- `?q=0|1|2` — Force quality tier (`2` = GTAO + Bloom, `1` = Bloom only, `0` = Minimal).
- `?dpr=1.0` — Force device pixel ratio.
- `?nostory` — Skip straight to `#content`.
