/**
 * Classic (non-module) script loaded in <head>.
 * Defines window.L(primary, secondary), language dictionary, data-i18n application,
 * and language toggle persistence so every module and canvas drawing can call L() from line 1.
 */
(function () {
  var STORAGE_KEY = 'rj_portfolio_lang';
  var saved = null;
  try {
    saved = window.localStorage.getItem(STORAGE_KEY);
  } catch (e) {}

  var htmlEl = document.documentElement;
  var initialLang = saved === 'fil' || saved === 'en' ? saved : 'en';
  window.__LANG = initialLang;
  if (htmlEl) {
    htmlEl.setAttribute('lang', initialLang);
  }

  /**
   * Returns primary (English) or secondary (Filipino) string according to active language.
   */
  window.L = function (en, fil) {
    if (window.__LANG === 'fil' && typeof fil === 'string' && fil.length > 0) {
      return fil;
    }
    return en;
  };

  /**
   * Central dictionary of all story beats, loader boot stages, UI labels, and accessibility copy.
   */
  window.STORY_COPY = {
    meta: {
      name: 'Rj Verceles',
      roleEn: 'Full Stack Developer & Web Designer',
      roleFil: 'Full Stack Developer at Web Designer',
      location: 'Zambales',
      chipEn: 'Rj Verceles · Zambales',
      chipFil: 'Rj Verceles · Zambales',
      firstLine1En: "I DON'T DECORATE —",
      firstLine2En: 'I SOLVE THE TASK.',
      firstLine1Fil: 'HINDI AKO NAGDEDEKORASYON —',
      firstLine2Fil: 'NILULUTAS KO ANG PROBLEMA.',
    },
    loader: [
      { threshold: 0, en: 'Curious?', fil: 'Kuryoso?', file: 'boot/curiosity.sys' },
      { threshold: 25, en: 'Drawing', fil: 'Gumuguhit', file: 'desk/sketchbook_v1.drw' },
      { threshold: 55, en: 'Testing', fil: 'Sinusubok', file: 'room/cardboard_mesh.shd' },
      { threshold: 85, en: 'Fixing', fil: 'Inaayos', file: 'canvas/pipeline_v11.bin' },
      { threshold: 96, en: 'Ready to work', fil: 'Handa nang magtrabaho', file: 'zambales/studio_ready.ok' },
    ],
    loaderWarmup: {
      en: 'Warming up shaders',
      fil: 'Inihahanda ang shaders',
    },
    loaderError: {
      en: "Couldn't load 3D scene, please refresh",
      fil: 'Hindi ma-load ang 3D, paki-refresh ang pahina',
    },
    connectPrompt: {
      line1En: 'DRAG THE STYLUS CABLE TO THE CANVAS PORT',
      line2En: 'OR PRESS ENTER TO CONNECT',
      line1Fil: 'IHILA ANG KABLE SA CANVAS PORT',
      line2Fil: 'O PINDUTIN ANG ENTER PARA KUMONEKTA',
    },
    beats: {
      b1: {
        en: 'It all starts with curiosity. I kept asking how a drawing becomes something people can actually use.',
        fil: 'Lahat ay nagsisimula sa kuryusidad. Lagi kong tinatanong kung paano nagiging bagay na magagamit ng tao ang isang guhit.',
      },
      b2: {
        en: 'I started on paper, in Zambales. A sketch, a pencil, a problem to solve — not decoration.',
        fil: 'Nagsimula ako sa papel, sa Zambales. Isang sketch, isang lapis, isang problemang kailangang lutasin — hindi dekorasyon.',
      },
      b3: {
        en: "Then the desk got glossy. Bright, loud, impressive — and hard to use. Beauty for beauty's sake doesn't sell.",
        fil: 'Pagkatapos, naging makintab ang mesa. Maliwanag, maingay, kahanga-hanga — pero mahirap gamitin. Ang ganda para sa ganda lang ay hindi nagbebenta.',
      },
      b4: {
        en: "I don't decorate. I solve the task: so people notice it, and so it works.",
        fil: 'Hindi ako nagdedekorasyon. Nilulutas ko ang problema: para mapansin ito, at para gumana ito.',
      },
      b5: {
        en: "One launch broke. Sketch not found. Blank page. The deadline didn't move.",
        fil: 'May isang launch na nasira. Sketch not found. Blangkong page. Hindi umusad ang deadline.',
      },
      b6: {
        en: 'I fixed it line by line. No magic, no excuses — test, fix, test again.',
        fil: 'Inayos ko ito linya por linya. Walang magic, walang dahilan — test, ayos, test ulit.',
      },
      b7: {
        en: 'The calm version shipped. Not the loudest work — the one that worked. People used it, and it sold.',
        fil: 'Nailabas ang kalmadong bersyon. Hindi ang pinakamaingay — ang gumana. Ginamit ito ng mga tao, at nagbenta ito.',
      },
      b8: {
        en: "Still curious. Still solving. If you have a task, not just a pretty idea — let's build it.",
        fil: 'Kuryoso pa rin. Lumulutas pa rin. Kung may problema kang kailangang lutasin, hindi lang magandang ideya — buuin natin.',
      },
    },
    wall1: {
      leadEn: 'It all starts with curiosity. I started on paper, in Zambales.',
      bigEn: 'A PROBLEM TO SOLVE — NOT DECORATION.',
      leadFil: 'Nagsisimula sa kuryusidad. Nagsimula ako sa papel, sa Zambales.',
      bigFil: 'PROBLEMANG LULUTASIN — HINDI DEKORASYON.',
    },
    wall2: {
      leadEn: 'Then the desk got glossy. Bright, loud — and hard to use.',
      bigEn: "BEAUTY FOR BEAUTY'S SAKE DOESN'T SELL.",
      leadFil: 'Naging makintab ang mesa. Maliwanag, maingay — mahirap gamitin.',
      bigFil: 'ANG GANDA LANG AY HINDI NAGBEBENTA.',
    },
  };

  window.I18N_STRINGS = {
    'sr.h1': [
      "Rj Verceles — Full Stack Developer & Web Designer in Zambales. I don't decorate — I solve the task.",
      'Rj Verceles — Full Stack Developer at Web Designer sa Zambales. Hindi ako nagdedekorasyon — nilulutas ko ang problema.',
    ],
    'header.role': [
      'Full Stack Developer & Web Designer · Zambales',
      'Full Stack Developer at Web Designer · Zambales',
    ],
    'header.sound': ['Sound', 'Tunog'],
    'ui.skip': ['Skip the story', 'Laktawan ang kwento'],
    'ui.hint.scroll': ['Scroll to look around', 'Mag-scroll para tumingin'],
    'ui.hint.hold': ['Press and hold', 'Pindutin nang matagal'],
    'ui.hint.button': ['Press the button', 'Pindutin ang button'],
    'ui.era.modern': ['Switching to the modern setup', 'Lumilipat sa modernong setup'],
    'ui.replay': ['Watch the story again', 'Panoorin ulit ang kwento'],
    'end.lead': [
      'Still curious. Still solving.',
      'Kuryoso pa rin. Lumulutas pa rin.',
    ],
    'end.big': [
      "IF YOU HAVE A TASK, NOT JUST A PRETTY IDEA — LET'S BUILD IT.",
      'KUNG MAY PROBLEMA KANG LULUTASIN — BUUIN NATIN.',
    ],
    'os.aria': ['Computer screen', 'Screen ng computer'],
    'os.icon.projects': ['My projects', 'Mga proyekto'],
    'os.icon.sketches': ['My sketches', 'Mga sketch ko'],
    'os.icon.drafts': ['Old drafts', 'Lumang draft'],
    'os.win.header': ['canvas-updater.exe', 'canvas-updater.exe'],
    'os.win.title': ['Update available', 'May bagong update'],
    'os.btn.hold': ['PRESS AND HOLD', 'PINDUTIN NANG MATAGAL'],
    'os.btn.updating': ['UPDATING...', 'INA-UPDATE...'],
    'os.btn.keep': ['KEEP HOLDING', 'HUWAG BITAWAN'],
    'dlg.statement.eyebrow': [
      'It all starts with curiosity — from paper in Zambales to real tools',
      'Nagsimula sa kuryusidad — mula sa papel sa Zambales hanggang sa totoong gamit',
    ],
    'dlg.statement.line1': ["I DON'T DECORATE.", 'HINDI AKO NAGDEDEKORASYON.'],
    'dlg.statement.line2': [
      'I SOLVE THE TASK: SO PEOPLE NOTICE IT, AND SO IT WORKS.',
      'NILULUTAS KO ANG PROBLEMA: PARA MAPANSIN AT GUMANA ITO.',
    ],
    'dlg.statement.btn': ['Continue', 'Magpatuloy'],
    'dlg.error.eyebrow': ['Error: sketch_not_found', 'Error: sketch_not_found'],
    'dlg.error.line1': ['ONE LAUNCH BROKE. BLANK PAGE.', 'NASIRA ANG LAUNCH. BLANGKONG PAGE.'],
    'dlg.error.line2': [
      "THE DEADLINE DIDN'T MOVE. I FIXED IT LINE BY LINE — TEST, FIX, TEST AGAIN.",
      'HINDI UMUSAD ANG DEADLINE. INAYOS KO LINYA POR LINYA — TEST, AYOS, TEST ULIT.',
    ],
    'dlg.error.btn': ['Try again', 'Subukan ulit'],
    'dlg.success.eyebrow': ['Update complete · Canvas 11', 'Tapos na ang update · Canvas 11'],
    'dlg.success.line1': ['THE CALM VERSION SHIPPED.', 'NAILABAS ANG KALMADONG BERSYON.'],
    'dlg.success.line2': ['NOT THE LOUDEST WORK — THE ONE THAT WORKED.', 'HINDI ANG PINAKAMAINGAY — ANG GUMANA.'],
    'dlg.success.line3': ['PEOPLE USED IT, AND IT SOLD.', 'GINAMIT ITO NG MGA TAO, AT NAGBENTA ITO.'],
    'dlg.success.btn': ['Done', 'Tapos na'],
    'beat.1': [window.STORY_COPY.beats.b1.en, window.STORY_COPY.beats.b1.fil],
    'beat.2': [window.STORY_COPY.beats.b2.en, window.STORY_COPY.beats.b2.fil],
    'beat.3': [window.STORY_COPY.beats.b3.en, window.STORY_COPY.beats.b3.fil],
    'beat.4': [window.STORY_COPY.beats.b4.en, window.STORY_COPY.beats.b4.fil],
    'beat.5': [window.STORY_COPY.beats.b5.en, window.STORY_COPY.beats.b5.fil],
    'beat.6': [window.STORY_COPY.beats.b6.en, window.STORY_COPY.beats.b6.fil],
    'beat.7': [window.STORY_COPY.beats.b7.en, window.STORY_COPY.beats.b7.fil],
    'beat.8': [window.STORY_COPY.beats.b8.en, window.STORY_COPY.beats.b8.fil],
  };

  window.applyLang = function (nextLang) {
    if (nextLang === 'en' || nextLang === 'fil') {
      window.__LANG = nextLang;
      try {
        window.localStorage.setItem(STORAGE_KEY, nextLang);
      } catch (e) {}
    }
    var lang = window.__LANG;
    if (document.documentElement) {
      document.documentElement.setAttribute('lang', lang);
    }

    var nodes = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var key = el.getAttribute('data-i18n');
      var pair = window.I18N_STRINGS[key];
      if (pair) {
        el.textContent = lang === 'fil' ? pair[1] : pair[0];
      }
    }

    var ariaNodes = document.querySelectorAll('[data-i18n-aria]');
    for (var j = 0; j < ariaNodes.length; j++) {
      var aEl = ariaNodes[j];
      var aKey = aEl.getAttribute('data-i18n-aria');
      var aPair = window.I18N_STRINGS[aKey];
      if (aPair) {
        aEl.setAttribute('aria-label', lang === 'fil' ? aPair[1] : aPair[0]);
      }
    }

    var langBtn = document.getElementById('lang-toggle');
    if (langBtn) {
      langBtn.textContent = lang === 'fil' ? 'FIL' : 'EN';
      langBtn.setAttribute(
        'aria-label',
        lang === 'fil'
          ? 'Palitan ang wika sa Ingles (Kasalukuyan: Filipino)'
          : 'Switch language to Filipino (Current: English)'
      );
    }

    window.dispatchEvent(new CustomEvent('langchange', { detail: { lang: lang } }));
  };

  window.toggleLang = function () {
    var next = window.__LANG === 'en' ? 'fil' : 'en';
    window.applyLang(next);
  };
})();
