# Rj Verceles — Interactive 3D Portfolio (Part 1: The Interactive 3D Story)

Interactive 3D opening story for **Rj Verceles** (*Full Stack Developer & Web Designer · Zambales*), built with **Vite**, **Vanilla ES Modules**, **Three.js (0.170.x)**, custom GLSL shaders, procedural Web Audio synthesis, and bilingual English/Filipino dictionaries.

---

## 1. Setup & Run Commands

```bash
npm install
npm run dev      # Starts dev server on http://localhost:3000
npm run build    # Builds production bundle into dist/
npm run preview  # Previews production build
```

Run the unit test suite for timeline & scroll-gating logic:

```bash
npx --yes tsx --test src/timeline.test.js
```

---

## 2. Story Timeline Table (`vh` & Normalized Constants)

All timings live in `src/timeline.js` (`CHAPTERS`, `TIMELINE`, `OS_TIMES`). Total track height before `#content` is **920 vh**:

| Chapter / Beat | Range (`vh` or `p1`/`mod`) | Behavior & Mechanics |
| :--- | :--- | :--- |
| `screen` (60 vh) & `room` (140 vh) | `pv`: `0 – 200` (`p1 = clamp(pv / 200)`) | Opening CRT close-up -> camera pull-back (`p1: 0.12 – 0.66`), haze clearing (`p1: 0.18 – 0.78`), cardboard-to-real fibrous reveal (`p1: 0.42 – 0.90`, `0 -> 3.2 m`), 10% cardboard floor memory (`p1: 0.70 – 0.95`). |
| Wall Headline 1 | In: `p1 [0.60, 0.76]` (`pv [120, 152]`), Out: `pv [225, 255]` | HTML `<h2 class="wall-copy">` locked to 3D wall anchor `(0, 1.925, -1.28)` above old CRT monitor. |
| `hold` (40 vh) & `modern` (220 vh) | `pv`: `245 – 425` (`mod = range(pv, 245, 425)`) | **Wave A** (`mod: 0.02 – 0.46`) covers old room in kraft cardboard; **Era Swap** at `mod = 0.5` (`pv = 335`) flips old/new meshes in vertex shader and re-bakes shadows once; **Wave B** (`mod: 0.54 – 0.98`) reveals modern room; lighting grades warm `#ff9a45` to cool `#c8dcff` and fades in LED strip. |
| Wall Headline 2 | In: `pv [430, 470]`, Out: `pv [500, 522]` | Second HTML headline projected above `SCREEN_modern`. |
| `push` (70 vh) | `pv`: `510 – 575` | Camera pushes into `CLOSE_M` (FOV 30) framing `SCREEN_modern`. |
| `os` (100 vh) — Hold Gate | `OS_TIMES.in`: `[366, 380]`, `hold`: `{ show: 586, at: 600, next: 602 }` | 2-stage Press-and-Hold (`1.8s` per stage) morphs OS from Skin 1 (pixel art) -> Skin 2 (glossy) -> Skin 3 (flat modern), updating `Canvas 7` to `Canvas 11` with tension, jitter, camera FOV tightening, and stretched audio riser. |
| `dialogs` (90 vh) — 3 Dialogs | `statement`: `{ show: 692, at: 705, next: 719 }`<br>`error`: `{ show: 718, at: 735, next: 749 }`<br>`success`: `{ show: 748, at: 765, next: 830 }` | Armed dialogs (`0.75s` button charge bar). Error dialog triggers red monochrome overlay + `.glitch` shake. Scroll is refused at each unfinished gate with card bounce `nudge()` and hint pill. |
| `exit` (70 vh) & `end` (50 vh) | `OS_TIMES.out`: `[772, 830]`, Finale: `pv >= 815` | Camera pulls back to `WIDE` shot, finale headline & replay button fade in, `#content` paper sheet peeks ~10% and rises over the room at `920 vh`. |

---

## 3. Replacing the Procedural Room with a GLB (Naming Convention)

`src/room.js` (`buildOrLoadRoom`) accepts a `glbUrl` (loaded via `GLTFLoader` + `MeshoptDecoder`) with zero code changes if the GLB uses these object names:

- `CRT` (`THREE.Group`): Hero rig group on the desk.
- `SCREEN` (or any mesh starting with `SCREEN` except `SCREEN_modern`): Old-era 4:3 CRT screen mesh receiving the CRT shader & connect-screen texture.
- `SCREEN_modern`: New-era 16:9 monitor panel mesh (`userData.era = "new"`) used to project the `1600x914` OS UI layer.
- `LAMP BULB`: Emissive bulb mesh on the old-era desk lamp (`userData.era = "old"`).
- `NEW_Lamp_bulb`: Emissive bulb mesh on the modern-era desk lamp (`userData.era = "new"`).
- `WINDOW - night sky`: Window backdrop plane mesh.
- Tag old-only props with `userData.era = "old"` and modern-only props with `userData.era = "new"`.

---

## 4. Editing Story Copy & Languages

All bilingual strings (English `en` primary + Filipino `fil` secondary) live in `src/lang.js`:
- `window.STORY_COPY`: Contains `meta` (name, role, location, first-screen chip & 2-line headline), `loader` boot stages (`0 / 25 / 55 / 85 / 96`), `connectPrompt`, `beats` (all 8 story beats), and `wall1` / `wall2` copy.
- `window.I18N_STRINGS`: Key-value pairs applied automatically to `[data-i18n]` and `[data-i18n-aria]` DOM elements via `window.applyLang()`.
- Call `window.L(enString, filString)` anywhere in JS or Canvas drawing code.

---

## 5. Swapping Audio

`src/music.js` synthesizes the ambient pad loop (as an in-memory stereo WAV Blob played by an `HTMLAudioElement` routed through a Web Audio `GainNode` for iOS compatibility) and pre-decodes procedural `AudioBuffer`s for `click`, `start`, `next`, `error`, `done`, and `riser`. To use external audio files instead, replace `audioEl.src` in `ensureContext()` and decode your `.mp3`/`.wav` files in `buildSfxBuffers()`.

---

## 6. Query Parameters & Performance Notes

- `?v=300` — Freeze story at a specific `vh` position (e.g., `?v=0`, `?v=140`, `?v=335`, `?v=450`, `?v=600`, `?v=705`, `?v=735`, `?v=765`, `?v=850`).
- `?p=0.5` — Freeze story at a normalized fraction (`0.0 – 1.0`) of the `920 vh` track.
- `?skin=2` — Preview OS Skin 2 (glossy era) when inspecting `?v=600`.
- `?motion=reduce` — Activate calm reduced-motion mode.
- `?q=0|1|2` — Force quality tier (`2` = GTAO + Bloom, `1` = Bloom only, `0` = Minimal).
- `?dpr=1.0` — Force device pixel ratio.
- `?nostory` — Skip straight to `#content`.

---

## 7. Manual Test Checklist

- [x] Loader steps through `0 / 25 / 55 / 85 / 96` boot messages, pre-compiles shaders at 97%, and fades out at 100%.
- [x] CRT connect screen allows dragging the stylus plug (or pressing `Enter` / `Space`) into the canvas socket, triggers audio + tube flicker, and reveals the first story screen.
- [x] Scrolling pulls camera back from `CLOSE` to `WIDE`, clears haze, reveals the room from kraft cardboard, and animates Wall Headline 1.
- [x] Scrolling through `245 – 425 vh` runs Cardboard Wave A, swaps old/new eras at `mod = 0.5`, runs Wave B, grades lighting warm-to-cool, and shows Wall Headline 2.
- [x] Camera pushes into `SCREEN_modern`; scroll is refused at `600 vh` until the 2-stage Press-and-Hold button completes Skin 1 -> Skin 2 -> Skin 3 (`Canvas 7 -> Canvas 11`).
- [x] Statement, Error (with red monochrome overlay & glitch), and Success dialogs charge their buttons (`0.75s`) and advance gates on click.
- [x] Finale headline & Replay button appear as `#content` paper sheet rises at `920 vh`.
- [x] Tested at `1440x900` (desktop) and `390x844` (mobile), with `EN`/`FIL` language toggle and reduced motion.
