import test from 'node:test';
import assert from 'node:assert/strict';
import {
  TOTAL_STORY_VH,
  clamp,
  lerp,
  range,
  ease,
  computeTimelineState,
  getFirstUnfinishedGate,
  limitScrollPv,
} from './timeline.js';

test('total chapter height sums to 920 vh', () => {
  assert.equal(TOTAL_STORY_VH, 920);
});

test('math utilities clamp, range, and ease behave deterministically', () => {
  assert.equal(clamp(-5, 0, 10), 0);
  assert.equal(clamp(15, 0, 10), 10);
  assert.equal(lerp(10, 20, 0.5), 15);
  assert.equal(range(50, 0, 100), 0.5);
  assert.equal(ease(0), 0);
  assert.equal(ease(0.5), 0.5);
  assert.equal(ease(1), 1);
});

test('computeTimelineState transitions eras at mod = 0.5 (pv = 335)', () => {
  const beforeSwap = computeTimelineState(330);
  assert.equal(beforeSwap.isNewEra, false);
  assert.equal(beforeSwap.waveB, -1);

  const afterSwap = computeTimelineState(340);
  assert.equal(afterSwap.isNewEra, true);

  const lateMod = computeTimelineState(410);
  assert.ok(lateMod.waveB > 1.0);
  assert.ok(lateMod.gradeK > 0.8);
});

test('scroll gating clamps pv at the first unfinished gate', () => {
  const initialGates = {
    hold: { done: false },
    statement: { done: false },
    error: { done: false },
    success: { done: false },
  };
  assert.equal(getFirstUnfinishedGate(initialGates)?.id, 'hold');
  assert.equal(limitScrollPv(650, initialGates), 600);

  const afterHold = {
    ...initialGates,
    hold: { done: true },
  };
  assert.equal(getFirstUnfinishedGate(afterHold)?.id, 'statement');
  assert.equal(limitScrollPv(720, afterHold), 705);

  const allDone = {
    hold: { done: true },
    statement: { done: true },
    error: { done: true },
    success: { done: true },
  };
  assert.equal(getFirstUnfinishedGate(allDone), null);
  assert.equal(limitScrollPv(900, allDone), 900);
});
