import * as THREE from 'three';

/**
 * Shared uniforms for the cardboard-to-real reveal and old-to-new era morph shader.
 */
export const cardUniforms = {
  uCardTex: { value: null },
  uHeroCenter: { value: new THREE.Vector3(0, 1.04, -1.05) },
  uReveal: { value: 0.0 },
  uCardFloor: { value: 0.0 },
  uMod: { value: 0.0 },
  uWaveA: { value: -0.2 },
  uWaveB: { value: -1.0 },
};

let cachedCardTexture = null;

/**
 * Generates a 1024x1024 (or 512x512 on phones) procedural kraft cardboard CanvasTexture:
 * - Warm kraft base
 * - ~90 blotchy radial pulp tones
 * - Faint corrugated flute stripes every 12 px
 * - ~9000 short random fibre strokes
 */
export function makeCardboard(isPhone = false) {
  if (cachedCardTexture) return cachedCardTexture;

  const size = isPhone ? 512 : 1024;
  const scale = size / 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  // 1. Kraft base
  ctx.fillStyle = '#B99364';
  ctx.fillRect(0, 0, size, size);

  // Deterministic pseudo-random generator so visual captures are consistent
  let seed = 42197;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  // 2. ~90 blotchy radial pulp tones
  for (let i = 0; i < 90; i++) {
    const x = rand() * size;
    const y = rand() * size;
    const r = (35 + rand() * 115) * scale;
    const grad = ctx.createRadialGradient(x, y, 0, x, y, r);
    const dark = rand() > 0.48;
    const alpha = 0.04 + rand() * 0.07;
    grad.addColorStop(0, dark ? `rgba(92, 66, 38, ${alpha})` : `rgba(214, 182, 138, ${alpha})`);
    grad.addColorStop(1, 'rgba(185, 147, 100, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // 3. Faint corrugated flute stripes every 12 px
  const step = Math.max(4, Math.round(12 * scale));
  for (let x = 0; x < size; x += step) {
    ctx.fillStyle = 'rgba(78, 54, 28, 0.045)';
    ctx.fillRect(x, 0, Math.max(1, Math.round(3 * scale)), size);
    ctx.fillStyle = 'rgba(235, 205, 165, 0.035)';
    ctx.fillRect(x + Math.max(1, Math.round(4 * scale)), 0, Math.max(1, Math.round(2 * scale)), size);
  }

  // 4. ~9000 short random fibre strokes
  const fibreCount = isPhone ? 4500 : 9000;
  ctx.lineWidth = Math.max(0.8, 1.1 * scale);
  for (let i = 0; i < fibreCount; i++) {
    const x = rand() * size;
    const y = rand() * size;
    const len = (3 + rand() * 9) * scale;
    const ang = rand() * Math.PI * 2;
    const tone = rand();
    if (tone < 0.45) {
      ctx.strokeStyle = 'rgba(72, 48, 24, 0.14)';
    } else if (tone < 0.82) {
      ctx.strokeStyle = 'rgba(142, 106, 68, 0.13)';
    } else {
      ctx.strokeStyle = 'rgba(238, 212, 174, 0.12)';
    }
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;

  cachedCardTexture = tex;
  cardUniforms.uCardTex.value = tex;
  return tex;
}

/**
 * Patches a MeshStandardMaterial with onBeforeCompile to support:
 * - Triplanar-by-dominant-normal cardboard sampling
 * - Fibrous torn-edge reveal (uReveal) and 10% cardboard floor memory (uCardFloor)
 * - Old/New era vertex off-screen push (uMod >= 0.5 pushes old meshes to (0,-50,0), brings new meshes in)
 * - Wave A and Wave B cardboard morph waves
 */
export function cardboardify(material, eraTag = 'static') {
  const eraFlag = eraTag === 'old' ? 1.0 : eraTag === 'new' ? 2.0 : 0.0;
  material.userData.eraTag = eraTag;
  material.customProgramCacheKey = () => `cardboard_${eraTag}_${material.uuid}`;

  material.onBeforeCompile = (shader) => {
    shader.uniforms.uCardTex = cardUniforms.uCardTex;
    shader.uniforms.uHeroCenter = cardUniforms.uHeroCenter;
    shader.uniforms.uReveal = cardUniforms.uReveal;
    shader.uniforms.uCardFloor = cardUniforms.uCardFloor;
    shader.uniforms.uMod = cardUniforms.uMod;
    shader.uniforms.uWaveA = cardUniforms.uWaveA;
    shader.uniforms.uWaveB = cardUniforms.uWaveB;
    shader.uniforms.uEraFlag = { value: eraFlag };

    material.userData.shader = shader;

    shader.vertexShader =
      `
      uniform float uMod;
      uniform float uEraFlag;
      varying vec3 vCardWorldPos;
      varying vec3 vCardWorldNorm;
      ` +
      shader.vertexShader
        .replace(
          '#include <beginnormal_vertex>',
          `
          #include <beginnormal_vertex>
          vCardWorldNorm = normalize(mat3(modelMatrix) * objectNormal);
          `
        )
        .replace(
          '#include <project_vertex>',
          `
          vec4 cardWp = modelMatrix * vec4(transformed, 1.0);
          if (uEraFlag > 0.5 && uEraFlag < 1.5 && uMod >= 0.5) {
            cardWp.xyz = vec3(0.0, -50.0, 0.0);
          } else if (uEraFlag > 1.5 && uMod < 0.5) {
            cardWp.xyz = vec3(0.0, -50.0, 0.0);
          }
          vCardWorldPos = cardWp.xyz;
          vec4 mvPosition = viewMatrix * cardWp;
          gl_Position = projectionMatrix * mvPosition;
          `
        );

    shader.fragmentShader =
      `
      uniform sampler2D uCardTex;
      uniform vec3 uHeroCenter;
      uniform float uReveal;
      uniform float uCardFloor;
      uniform float uMod;
      uniform float uWaveA;
      uniform float uWaveB;
      varying vec3 vCardWorldPos;
      varying vec3 vCardWorldNorm;
      ` +
      shader.fragmentShader
        .replace(
          '#include <color_fragment>',
          `
          #include <color_fragment>
          vec3 an = abs(normalize(vCardWorldNorm));
          vec2 cardUv;
          if (an.x >= an.y && an.x >= an.z) {
            cardUv = vCardWorldPos.zy * 0.65;
          } else if (an.y >= an.x && an.y >= an.z) {
            cardUv = vCardWorldPos.xz * 0.65;
          } else {
            cardUv = vCardWorldPos.xy * 0.65;
          }
          vec4 cardTex = texture2D(uCardTex, cardUv);
          float edgeNoise = (cardTex.r - 0.55) * 0.5;
          float wd = distance(vCardWorldPos, uHeroCenter) + edgeNoise;

          // Initial cardboard-to-real reveal
          float revealCard = smoothstep(uReveal - 0.14, uReveal + 0.14, wd);
          float cardMix = max(revealCard, uCardFloor);

          // Modernisation Wave A & Wave B
          float wA = 1.0 - smoothstep(uWaveA - 0.12, uWaveA + 0.12, wd);
          float wB = uWaveB < -0.5 ? 1.0 : smoothstep(uWaveB - 0.12, uWaveB + 0.12, wd);
          cardMix = max(cardMix, wA * wB);
          cardMix = clamp(cardMix, 0.0, 1.0);

          vec3 kraftLinear = pow(cardTex.rgb, vec3(2.2)) * vec3(0.95, 0.86, 0.72);
          diffuseColor.rgb = mix(diffuseColor.rgb, kraftLinear, cardMix);
          `
        )
        .replace(
          '#include <roughnessmap_fragment>',
          `
          #include <roughnessmap_fragment>
          roughnessFactor = mix(roughnessFactor, 1.0, cardMix);
          `
        )
        .replace(
          '#include <metalnessmap_fragment>',
          `
          #include <metalnessmap_fragment>
          metalnessFactor = mix(metalnessFactor, 0.0, cardMix);
          `
        )
        .replace(
          '#include <emissivemap_fragment>',
          `
          #include <emissivemap_fragment>
          totalEmissiveRadiance *= (1.0 - cardMix);
          `
        );
  };

  return material;
}

export function disposeCardboard() {
  if (cachedCardTexture) {
    cachedCardTexture.dispose();
    cachedCardTexture = null;
  }
}
