/**
 * Pure scroll-timeline constants, math helpers, and scroll-gate limit calculations.
 * Kept decoupled from DOM/WebGL so deterministic unit tests can verify all transitions.
 */

export const CHAPTERS = [
  { id: 'screen', vh: 60 },
  { id: 'room', vh: 140 },
  { id: 'hold', vh: 40 },
  { id: 'modern', vh: 220 },
  { id: 'tech', vh: 80 },
  { id: 'push', vh: 70 },
  { id: 'os', vh: 100 },
  { id: 'dialogs', vh: 90 },
  { id: 'exit', vh: 70 },
  { id: 'end', vh: 50 },
];

export const TOTAL_STORY_VH = CHAPTERS.reduce((acc, c) => acc + c.vh, 0); // 920 vh

export const OS_TIMES = {
  in: [366, 380],
  gates: {
    hold: { id: 'hold', show: 586, at: 600, next: 602 },
    statement: { id: 'statement', show: 692, at: 705, next: 719 },
    error: { id: 'error', show: 718, at: 735, next: 749 },
    success: { id: 'success', show: 748, at: 765, next: 830 },
  },
  out: [772, 830],
};

export const TIMELINE = {
  pullBackSpan: 200,
  pullBackCamera: [0.12, 0.66],
  hazeClear: [0.18, 0.78],
  cardReveal: [0.42, 0.90],
  cardRevealRadius: 3.2,
  cardFloor: [0.70, 0.95],
  cardFloorMax: 0.1,
  wall1InP1: [0.60, 0.76],
  wall1OutPv: [225, 255],
  modPv: [245, 425],
  waveAMod: [0.02, 0.46],
  waveBMod: [0.54, 0.98],
  waveRange: [-0.2, 3.4],
  gradeMod: [0.05, 0.90],
  ledMod: [0.35, 0.80],
  wall2InPv: [430, 470],
  wall2OutPv: [500, 522],
  pushInPv: [510, 575],
  exitPv: [772, 830],
  endAtPv: 815,
  os: OS_TIMES,
};

export function clamp(x, min = 0, max = 1) {
  return x < min ? min : x > max ? max : x;
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

export function range(x, a, b) {
  if (a === b) return x >= b ? 1 : 0;
  return clamp((x - a) / (b - a), 0, 1);
}

export function ease(t) {
  const c = clamp(t, 0, 1);
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
}

/**
 * Computes all normalized timeline parameters for a given story scroll position `pv` (in vh).
 */
export function computeTimelineState(pv) {
  const p1 = clamp(pv / TIMELINE.pullBackSpan, 0, 1);
  const pullT = ease(range(p1, TIMELINE.pullBackCamera[0], TIMELINE.pullBackCamera[1]));
  const hazeR = ease(range(p1, TIMELINE.hazeClear[0], TIMELINE.hazeClear[1]));
  const uReveal = lerp(0, TIMELINE.cardRevealRadius, ease(range(p1, TIMELINE.cardReveal[0], TIMELINE.cardReveal[1])));
  const uCardFloor = TIMELINE.cardFloorMax * ease(range(p1, TIMELINE.cardFloor[0], TIMELINE.cardFloor[1]));

  const wall1In = ease(range(p1, TIMELINE.wall1InP1[0], TIMELINE.wall1InP1[1]));
  const wall1Out = ease(range(pv, TIMELINE.wall1OutPv[0], TIMELINE.wall1OutPv[1]));

  const mod = range(pv, TIMELINE.modPv[0], TIMELINE.modPv[1]);
  const waveA = lerp(
    TIMELINE.waveRange[0],
    TIMELINE.waveRange[1],
    ease(range(mod, TIMELINE.waveAMod[0], TIMELINE.waveAMod[1]))
  );
  const waveB =
    mod < TIMELINE.waveBMod[0]
      ? -1
      : lerp(
          TIMELINE.waveRange[0],
          TIMELINE.waveRange[1],
          ease(range(mod, TIMELINE.waveBMod[0], TIMELINE.waveBMod[1]))
        );

  const gradeK = ease(range(mod, TIMELINE.gradeMod[0], TIMELINE.gradeMod[1]));
  const ledIntensity = 10 * ease(range(mod, TIMELINE.ledMod[0], TIMELINE.ledMod[1]));
  const isNewEra = mod >= 0.5;

  const wall2In = ease(range(pv, TIMELINE.wall2InPv[0], TIMELINE.wall2InPv[1]));
  const wall2Out = ease(range(pv, TIMELINE.wall2OutPv[0], TIMELINE.wall2OutPv[1]));

  const pushIn = ease(range(pv, TIMELINE.pushInPv[0], TIMELINE.pushInPv[1]));
  const pushOut = ease(range(pv, TIMELINE.exitPv[0], TIMELINE.exitPv[1]));
  const pushZ = pushIn * (1 - pushOut);

  const osIn = ease(range(pv, OS_TIMES.in[0], OS_TIMES.in[1]));
  const osOut = ease(range(pv, OS_TIMES.out[0], OS_TIMES.out[1]));
  const osOpacity = clamp(osIn * (1 - osOut), 0, 1);
  const osLive = pv >= OS_TIMES.in[1] && pv <= OS_TIMES.out[0];

  const atEnd = pv >= TIMELINE.endAtPv;

  return {
    pv,
    p1,
    pullT,
    hazeR,
    uReveal,
    uCardFloor,
    wall1In,
    wall1Out,
    mod,
    waveA,
    waveB,
    gradeK,
    ledIntensity,
    isNewEra,
    wall2In,
    wall2Out,
    pushIn,
    pushOut,
    pushZ,
    osIn,
    osOut,
    osOpacity,
    osLive,
    atEnd,
  };
}

/**
 * Returns the first unfinished gate in sequence, or null if all gates are completed.
 */
export function getFirstUnfinishedGate(gateStateMap) {
  const order = ['hold', 'statement', 'error', 'success'];
  for (const key of order) {
    const gateSpec = OS_TIMES.gates[key];
    const done = gateStateMap && gateStateMap[key] && gateStateMap[key].done;
    if (!done) {
      return gateSpec;
    }
  }
  return null;
}

/**
 * Clamps the story scroll position `pv` to the first unfinished gate's `at` point.
 */
export function limitScrollPv(pv, gateStateMap) {
  const firstGate = getFirstUnfinishedGate(gateStateMap);
  if (!firstGate) return pv;
  return Math.min(pv, firstGate.at);
}
