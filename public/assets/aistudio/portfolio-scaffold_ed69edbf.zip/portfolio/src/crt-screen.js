import * as THREE from 'three';

let displayFontLoaded = false;

/**
 * Ensures the Anton display face is loaded via FontFace() before drawing canvas text.
 */
export async function ensureDisplayFont() {
  if (displayFontLoaded) return;
  try {
    if (typeof FontFace !== 'undefined') {
      const ff = new FontFace('Anton', 'url(/assets/fonts/anton.woff2)', {
        weight: '400',
        style: 'normal',
      });
      const loaded = await ff.load();
      document.fonts.add(loaded);
    }
    await document.fonts.ready;
    displayFontLoaded = true;
  } catch (e) {
    displayFontLoaded = true;
  }
}

function drawRoundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/**
 * Creates and draws the 1440x1080 (4:3) first-screen canvas texture.
 * Includes the 6% RV watermark, translucent ring + accent pill chip ("Rj Verceles · Zambales")
 * with cursor arrow, and the 2-line 300px Anton headline with radial light gradient.
 */
export function createFirstStoryScreenTexture(maxAnisotropy = 8) {
  const canvas = document.createElement('canvas');
  canvas.width = 1440;
  canvas.height = 1080;
  const ctx = canvas.getContext('2d');

  const tex = new THREE.CanvasTexture(canvas);
  tex.flipY = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.anisotropy = Math.min(8, maxAnisotropy);

  function redraw() {
    const W = 1440;
    const H = 1080;
    const frameW = 1350;

    // 1. Background navy
    ctx.fillStyle = '#0B1020';
    ctx.fillRect(0, 0, W, H);

    // Subtle deep radial ambient glow inside 1350px design frame
    const bgGlow = ctx.createRadialGradient(W * 0.5, H * 0.56, 40, W * 0.5, H * 0.56, 680);
    bgGlow.addColorStop(0, 'rgba(124, 92, 255, 0.16)');
    bgGlow.addColorStop(0.6, 'rgba(20, 27, 51, 0.08)');
    bgGlow.addColorStop(1, 'rgba(11, 16, 32, 0)');
    ctx.fillStyle = bgGlow;
    ctx.fillRect((W - frameW) * 0.5, 0, frameW, H);

    // 2. Faint RV watermark (6% alpha, large, centred)
    ctx.save();
    ctx.globalAlpha = 0.06;
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '400 680px "Anton", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('RV', W * 0.5, H * 0.54);
    ctx.restore();

    // 3. Small pill chip at top-center
    const copy = window.STORY_COPY?.meta || {};
    const chipText = window.L
      ? window.L(copy.chipEn || 'Rj Verceles · Zambales', copy.chipFil || 'Rj Verceles · Zambales')
      : 'Rj Verceles · Zambales';

    ctx.font = '600 30px "Inter", sans-serif';
    const textMetrics = ctx.measureText(chipText);
    const innerPadX = 40;
    const innerW = Math.ceil(textMetrics.width + innerPadX * 2);
    const innerH = 64;
    const outerPad = 12;
    const outerW = innerW + outerPad * 2;
    const outerH = innerH + outerPad * 2;
    const outerX = (W - outerW) * 0.5;
    const outerY = 185;

    // Translucent outer ring with clipped soft blurred highlight ellipse
    ctx.save();
    drawRoundedRect(ctx, outerX, outerY, outerW, outerH, outerH * 0.5);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.stroke();
    ctx.clip();

    const hlGrad = ctx.createRadialGradient(
      W * 0.5,
      outerY + 8,
      4,
      W * 0.5,
      outerY + 8,
      outerW * 0.45
    );
    hlGrad.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
    hlGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = hlGrad;
    ctx.beginPath();
    ctx.ellipse(W * 0.5, outerY + 8, outerW * 0.42, 26, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Accent-coloured inner pill
    const innerX = outerX + outerPad;
    const innerY = outerY + outerPad;
    ctx.save();
    drawRoundedRect(ctx, innerX, innerY, innerW, innerH, innerH * 0.5);
    ctx.fillStyle = '#7C5CFF';
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '600 30px "Inter", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(chipText, W * 0.5, innerY + innerH * 0.5 + 1);
    ctx.restore();

    // Soft cursor-arrow shape hanging off bottom-right corner of the pill
    const curX = innerX + innerW - 14;
    const curY = innerY + innerH - 8;
    ctx.save();
    ctx.translate(curX, curY);
    ctx.fillStyle = '#F7F5EF';
    ctx.strokeStyle = '#0B1020';
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, 32);
    ctx.lineTo(9, 24);
    ctx.lineTo(16, 36);
    ctx.lineTo(22, 33);
    ctx.lineTo(15, 21);
    ctx.lineTo(26, 21);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // 4. Two-line giant headline in Anton (~250-300px, line-height 86%, uppercase)
    const enLine1 = (copy.firstLine1En || "I DON'T DECORATE —").toUpperCase();
    const enLine2 = (copy.firstLine2En || 'I SOLVE THE TASK.').toUpperCase();
    const line1 = window.L
      ? window.L(enLine1, (copy.firstLine1Fil || 'HINDI AKO NAGDEDEKORASYON —').toUpperCase())
      : enLine1;
    const line2 = window.L
      ? window.L(enLine2, (copy.firstLine2Fil || 'NILULUTAS KO ANG PROBLEMA.').toUpperCase())
      : enLine2;

    const baseFontSize = 235;
    const lineHeight = baseFontSize * 0.86;
    ctx.font = `400 ${baseFontSize}px "Anton", sans-serif`;

    const primaryMaxW = Math.min(
      frameW - 40,
      Math.max(ctx.measureText(enLine1).width, ctx.measureText(enLine2).width, 1180)
    );

    const textBoxTop = 365;
    const textBoxBottom = textBoxTop + lineHeight * 2;
    const textGrad = ctx.createRadialGradient(
      W * 0.5,
      textBoxTop + 60,
      40,
      W * 0.5,
      (textBoxTop + textBoxBottom) * 0.5,
      760
    );
    textGrad.addColorStop(0, '#FFFFFF');
    textGrad.addColorStop(0.65, '#F2EEFF');
    textGrad.addColorStop(1, '#E6E0FF');

    const lines = [line1, line2];
    lines.forEach((ln, idx) => {
      ctx.save();
      ctx.font = `400 ${baseFontSize}px "Anton", sans-serif`;
      const w = ctx.measureText(ln).width;
      const scale = w > primaryMaxW ? primaryMaxW / w : 1;
      const yCenter = textBoxTop + idx * lineHeight + baseFontSize * 0.44;
      ctx.translate(W * 0.5, yCenter);
      ctx.scale(scale, scale);
      ctx.fillStyle = textGrad;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(ln, 0, 0);
      ctx.restore();
    });

    tex.needsUpdate = true;
  }

  redraw();
  return { texture: tex, redraw, canvas };
}

/**
 * Inverse mapping of the CRT barrel distortion so pointer raycast UVs align with pixel coordinates.
 */
export function undistortCrtUv(vUvX, vUvY) {
  const cX = vUvX - 0.5;
  const cY = vUvY - 0.5;
  const r2 = cX * cX + cY * cY;
  const factor = (1.0 + 0.09 * r2 * 4.0) * 0.94;
  const u = 0.5 + cX * factor;
  // Flip Y because tex.flipY = false on canvas textures
  const v = 1.0 - (0.5 + cY * factor);
  return { u, v };
}

/**
 * Builds the CRT tube ShaderMaterial:
 * - Convex barrel distortion: uv = .5 + c * (1 + .09 * dot(c,c) * 4) * .94
 * - Scanlines faded by fwidth(uv.y) * 1080 so phones never alias
 * - Soft dark corners vignette
 * - Power uniform for tube flicker
 * - toneMapped: false, fog: false
 */
export function createCrtMaterial(initialTexture) {
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      tMap: { value: initialTexture },
      power: { value: 1.0 },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D tMap;
      uniform float power;
      varying vec2 vUv;

      void main() {
        vec2 c = vUv - 0.5;
        vec2 uv = 0.5 + c * (1.0 + 0.09 * dot(c, c) * 4.0) * 0.94;

        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
          gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
          return;
        }

        // Flip Y for tex.flipY = false canvas coordinates
        vec2 sampleUv = vec2(uv.x, 1.0 - uv.y);
        vec3 col = texture2D(tMap, sampleUv).rgb;

        // Scanlines with derivative fade-out when screen is small
        float fw = fwidth(uv.y) * 1080.0;
        float scanVis = 1.0 - smoothstep(0.35, 0.95, fw);
        float scan = 1.0 - 0.1 * scanVis * (0.5 - 0.5 * cos(uv.y * 1080.0 * 3.14159265));

        // Soft dark corners
        float vig = mix(0.55, 1.0, smoothstep(0.75, 0.3, length(c * vec2(1.0, 1.15))));

        gl_FragColor = vec4(col * scan * vig * power, 1.0);
      }
    `,
    toneMapped: false,
    fog: false,
  });

  return mat;
}

/**
 * Creates the 1600x900 modern screen texture (on SCREEN_modern, MeshBasicMaterial):
 * - Radial gradient from an accent glow at bottom centre to dark base
 * - 6 faint concentric ellipse arcs at 8% alpha
 * - RV logo centred at 90% alpha
 * - Dock-like rounded strip with 6 small coloured rounded squares
 */
export function createModernScreenTexture(isPhone = false) {
  const scale = isPhone ? 0.5 : 1;
  const W = Math.round(1600 * scale);
  const H = Math.round(900 * scale);
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);

  // 1. Radial gradient from accent glow at bottom centre to dark base
  ctx.fillStyle = '#0B1020';
  ctx.fillRect(0, 0, 1600, 900);

  const glow = ctx.createRadialGradient(800, 900, 30, 800, 880, 920);
  glow.addColorStop(0, 'rgba(124, 92, 255, 0.62)');
  glow.addColorStop(0.42, 'rgba(45, 212, 191, 0.18)');
  glow.addColorStop(1, 'rgba(11, 16, 32, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, 1600, 900);

  // 2. 6 faint concentric ellipse arcs at 8% alpha
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 2;
  for (let i = 1; i <= 6; i++) {
    ctx.beginPath();
    ctx.ellipse(800, 880, i * 155, i * 105, 0, Math.PI, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();

  // 3. Logo centred at 90% alpha
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = '#F7F5EF';
  ctx.font = '400 132px "Anton", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('RV', 800, 415);
  ctx.restore();

  // 4. Dock-like rounded strip with 6 small coloured rounded squares
  const dockW = 360;
  const dockH = 64;
  const dockX = (1600 - dockW) * 0.5;
  const dockY = 805;
  ctx.save();
  drawRoundedRect(ctx, dockX, dockY, dockW, dockH, 20);
  ctx.fillStyle = 'rgba(20, 27, 51, 0.78)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  const colors = ['#7C5CFF', '#2DD4BF', '#FFB86B', '#7FA6FF', '#F43F5E', '#A78BFA'];
  for (let i = 0; i < 6; i++) {
    const sqX = dockX + 22 + i * 54;
    const sqY = dockY + 14;
    drawRoundedRect(ctx, sqX, sqY, 36, 36, 9);
    ctx.fillStyle = colors[i];
    ctx.fill();
  }
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}
